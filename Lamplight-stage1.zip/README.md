# Lamplight · Stage 1

A private, offline-first writing app for iPhone. Plain HTML, CSS and JavaScript: no build step, no dependencies, no network requests.

## Put it on your iPhone
1. On github.com (in Safari), create a public repository named `lamplight`.
2. Unzip this folder in the Files app. In the repository choose **Add file → Upload files** and select everything inside it, keeping the `css`, `js`, `fonts` and `icons` folders.
3. Make **EB Garamond** the default: download it free from fonts.google.com (EB Garamond), then upload
   `EBGaramond-VariableFont_wght.ttf` and `EBGaramond-Italic-VariableFont_wght.ttf` into `fonts/`.
   Until those files are there, Lamplight uses Crimson Pro.
4. **Settings → Pages**: choose the `main` branch, then save. Your app will be at `https://<you>.github.io/lamplight/`.
5. Open that address in Safari, tap **Share → Add to Home Screen**, and always open Lamplight from that icon.

GitHub serves only the app's code. Your documents stay on the phone.

## Files
- `js/store.js`: storage (IndexedDB, plus a recovery copy written on every keystroke)
- `js/fonts.js`: typography registry (bundled, iPhone system and imported fonts). Add a typeface here.
- `js/app.js`: library, editor, formatting, font library, document settings, switcher
- `js/text.js`: word counts, plain text, paste cleaning · `js/ui.js`: panels, dialogs, icons
- `sw.js`: offline cache of the app itself. Bump `CACHE` whenever you change files.
