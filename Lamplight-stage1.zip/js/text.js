/* Lamplight — text utilities: counting, plain-text extraction, paste sanitising. */

const segW = typeof Intl !== 'undefined' && Intl.Segmenter ? new Intl.Segmenter(undefined, { granularity: 'word' }) : null;
const segS = typeof Intl !== 'undefined' && Intl.Segmenter ? new Intl.Segmenter(undefined, { granularity: 'sentence' }) : null;

export const ZW = /​/g;

export function countWords(text) {
  text = text.replace(ZW, '');
  if (!text.trim()) return 0;
  if (segW) { let n = 0; for (const s of segW.segment(text)) if (s.isWordLike) n++; return n; }
  return (text.match(/[\p{L}\p{N}][\p{L}\p{N}'’\-]*/gu) || []).length;
}
export function countSentences(text) {
  text = text.replace(ZW, '').trim();
  if (!text) return 0;
  if (segS) { let n = 0; for (const s of segS.segment(text)) if (/[\p{L}\p{N}]/u.test(s.segment)) n++; return n; }
  return (text.match(/[^.!?…]+[.!?…]+["'”’)]*|\S[^.!?…]*$/g) || []).length;
}

const BLOCKS = new Set(['P', 'H1', 'H2', 'H3', 'H4', 'BLOCKQUOTE', 'LI', 'DIV', 'UL', 'OL', 'HR', 'PRE']);

/* Plain text with a newline between blocks — keeps poem lines intact. */
export function plainText(root) {
  let out = '';
  const walk = n => {
    for (const c of n.childNodes) {
      if (c.nodeType === 3) out += c.nodeValue;
      else if (c.nodeType === 1) {
        if (c.tagName === 'BR') { out += '\n'; continue; }
        const b = BLOCKS.has(c.tagName);
        if (b && out && !out.endsWith('\n')) out += '\n';
        walk(c);
        if (b && !out.endsWith('\n')) out += '\n';
      }
    }
  };
  walk(root);
  return out.replace(ZW, '').replace(/\n{3,}/g, '\n\n').trim();
}

export function stats(root) {
  const text = plainText(root);
  const paras = [...root.querySelectorAll('p,h1,h2,h3,blockquote,li')].filter(b => b.textContent.replace(ZW, '').trim()).length;
  return {
    words: countWords(text),
    chars: text.replace(/\n/g, '').length,
    charsNoSpace: text.replace(/\s/g, '').length,
    paragraphs: paras,
    sentences: countSentences(text),
    sentencesReliable: !!segS,
    text,
  };
}

/* ---------- paste sanitiser: keep structure + basic emphasis, drop foreign styling ---------- */
const KEEP = { P: 'p', H1: 'h1', H2: 'h2', H3: 'h3', H4: 'h3', H5: 'h3', H6: 'h3', BLOCKQUOTE: 'blockquote', UL: 'ul', OL: 'ol', LI: 'li',
  B: 'strong', STRONG: 'strong', I: 'em', EM: 'em', U: 'u', S: 's', STRIKE: 's', DEL: 's', SUP: 'sup', SUB: 'sub', BR: 'br', A: 'a', DIV: 'p' };

export function sanitizeHTML(html) {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const out = document.createElement('div');
  const copy = (src, dst) => {
    for (const n of src.childNodes) {
      if (n.nodeType === 3) { dst.append(n.nodeValue.replace(/ /g, ' ')); continue; }
      if (n.nodeType !== 1) continue;
      if (/^(SCRIPT|STYLE|META|LINK|TITLE|IFRAME|OBJECT|NOSCRIPT|svg|IMG|VIDEO|AUDIO|BUTTON|INPUT|FORM)$/i.test(n.tagName)) continue;
      let tag = KEEP[n.tagName];
      // inline span carrying bold/italic from Google Docs/Word
      if (!tag && n.tagName === 'SPAN') {
        const st = n.getAttribute('style') || '';
        if (/font-weight:\s*(bold|[6-9]00)/i.test(st)) tag = 'strong';
        else if (/font-style:\s*italic/i.test(st)) tag = 'em';
      }
      if (!tag) { copy(n, dst); continue; }
      const el = document.createElement(tag);
      if (tag === 'a') { const h = n.getAttribute('href') || ''; if (/^https?:|^mailto:/i.test(h)) el.setAttribute('href', h); }
      const al = (n.getAttribute('style') || '').match(/text-align:\s*(center|right|justify)/i) || [];
      if (al[1] && /^(p|h1|h2|h3|blockquote)$/.test(tag)) el.style.textAlign = al[1].toLowerCase();
      copy(n, el);
      dst.append(el);
    }
  };
  copy(doc.body, out);
  // lift stray inline content into paragraphs
  const frag = document.createElement('div');
  let cur = null;
  for (const n of [...out.childNodes]) {
    const isBlock = n.nodeType === 1 && /^(P|H1|H2|H3|BLOCKQUOTE|UL|OL)$/.test(n.tagName);
    if (isBlock) { cur = null; frag.append(n); }
    else { if (n.nodeType === 3 && !n.nodeValue.trim() && !cur) continue; if (!cur) { cur = document.createElement('p'); frag.append(cur); } cur.append(n); }
  }
  return frag.innerHTML;
}

export function textToHTML(t) {
  const e = s => s.replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
  return t.replace(/\r\n?/g, '\n').split('\n').map(l => `<p>${l ? e(l) : '<br>'}</p>`).join('');
}
