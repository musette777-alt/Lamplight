/* Lamplight — small UI kit: icons, panels, dialogs, toast. No alert/confirm/prompt. */

const P = {
  search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.5 15.5 20 20"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  more: '<circle cx="5.5" cy="12" r="1.2" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.2" fill="currentColor" stroke="none"/><circle cx="18.5" cy="12" r="1.2" fill="currentColor" stroke="none"/>',
  list: '<path d="M4 6.5h16M4 12h16M4 17.5h16"/>',
  grid: '<rect x="4.5" y="4" width="6" height="8"/><rect x="13.5" y="4" width="6" height="8"/><rect x="4.5" y="14.5" width="6" height="6"/><rect x="13.5" y="14.5" width="6" height="6"/>',
  pen: '<path d="M14.5 5.5l4 4L9 19H5v-4z"/><path d="M12.5 7.5l4 4"/>',
  folder: '<path d="M3.5 7.5V18h17V9.5h-9l-2-2z"/>',
  folderplus: '<path d="M3.5 7.5V18h17V9.5h-9l-2-2z"/><path d="M12 12v4M10 14h4"/>',
  back: '<path d="M14.5 5.5 8 12l6.5 6.5"/>',
  chev: '<path d="M7 10l5 5 5-5"/>',
  star: '<path d="M12 4.5l2.3 4.8 5.2.7-3.8 3.6.9 5.2L12 16.4l-4.6 2.4.9-5.2-3.8-3.6 5.2-.7z"/>',
  copy: '<rect x="8" y="8" width="11" height="12"/><path d="M5 16V4.5h11"/>',
  move: '<path d="M3.5 7.5V18h17V9.5h-9l-2-2z"/><path d="M10 13.5h6M14 11.5l2 2-2 2"/>',
  rename: '<path d="M4 19h16"/><path d="M14.5 5.5l3 3L9 17H6v-3z"/>',
  trash: '<path d="M5 7h14M9.5 7V4.5h5V7M7 7l1 13h8l1-13"/>',
  restore: '<path d="M5 12a7 7 0 1 0 2-5"/><path d="M5 4v4h4"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M12 3.5v2.2M12 18.3v2.2M3.5 12h2.2M18.3 12h2.2M6 6l1.6 1.6M16.4 16.4 18 18M6 18l1.6-1.6M16.4 7.6 18 6"/>',
  bold: '<path d="M7.5 5h5.5a3.25 3.25 0 0 1 0 6.5H7.5zM7.5 11.5H14a3.5 3.5 0 0 1 0 7H7.5z" stroke-width="2"/>',
  italic: '<path d="M10.5 5H17M7 19h6.5M14 5l-4 14"/>',
  underline: '<path d="M7.5 4.5V11a4.5 4.5 0 0 0 9 0V4.5M6 20h12"/>',
  strike: '<path d="M5 12h14"/><path d="M16 7.5c-.7-1.7-2.2-2.5-4.1-2.5-2.3 0-3.9 1.2-3.9 3 0 1.2.8 2.2 2.6 2.8M8 16.3c.6 1.7 2.2 2.7 4.3 2.7 2.4 0 4-1.2 4-3.1 0-.6-.2-1.2-.6-1.6"/>',
  sup: '<path d="M4.5 8l7 9M11.5 8l-7 9"/><path d="M15.5 6.5a1.8 1.8 0 1 1 3 1.4L15.5 10.5h3.5"/>',
  sub: '<path d="M4.5 7l7 9M11.5 7l-7 9"/><path d="M15.5 15a1.8 1.8 0 1 1 3 1.4L15.5 19h3.5"/>',
  ul: '<circle cx="5.5" cy="7" r="1" fill="currentColor"/><circle cx="5.5" cy="12" r="1" fill="currentColor"/><circle cx="5.5" cy="17" r="1" fill="currentColor"/><path d="M9.5 7H20M9.5 12H20M9.5 17H20"/>',
  ol: '<path d="M4.5 5.5h1.5v4M4.5 9.5h3M4.5 14.5c.3-.7 2.8-1 2.8.6 0 1-2.8 2.4-2.8 3.4h3M10 7h10M10 12h10M10 17h10"/>',
  al: '<path d="M4 6h16M4 10h10M4 14h16M4 18h10"/>',
  ac: '<path d="M4 6h16M7 10h10M4 14h16M7 18h10"/>',
  ar: '<path d="M4 6h16M10 10h10M4 14h16M10 18h10"/>',
  aj: '<path d="M4 6h16M4 10h16M4 14h16M4 18h16"/>',
  indent: '<path d="M4 5h16M10 10h10M10 14h10M4 19h16M4 9.5l3 2.5-3 2.5"/>',
  outdent: '<path d="M4 5h16M10 10h10M10 14h10M4 19h16M7 9.5 4 12l3 2.5"/>',
  undo: '<path d="M9 7 5 11l4 4"/><path d="M5 11h9a5 5 0 0 1 0 10h-2"/>',
  redo: '<path d="M15 7l4 4-4 4"/><path d="M19 11h-9a5 5 0 0 0 0 10h2"/>',
  page: '<path d="M6 3.5h8.5L18 7v13.5H6z"/><path d="M14 3.5V7.5h4"/>',
  pagebreak: '<path d="M6 3.5h12v6H6zM6 14.5h12v6H6z"/><path d="M3.5 12h2M8 12h2M12 12h2M16 12h2M20 12h.5"/>',
  doc: '<path d="M6 3.5h8.5L18 7v13.5H6z"/><path d="M9 11h6M9 14.5h6M9 18h4"/>',
  type: '<path d="M5 7V5h14v2M12 5v14M9 19h6"/>',
  stats: '<path d="M5 19V11M10 19V5M15 19v-6M20 19V8"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  kbd: '<rect x="3" y="6" width="18" height="11" rx="1"/><path d="M7 10h.01M11 10h.01M15 10h.01M7 13.5h10M10 20l2 1.5 2-1.5"/>',
  check: '<path d="M5 12.5 10 17 19 7.5"/>',
  lock: '<rect x="5.5" y="10.5" width="13" height="9.5"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5"/>',
};
export const icon = (n, cls = '') => `<svg class="i ${cls}" viewBox="0 0 24 24" aria-hidden="true">${P[n] || ''}</svg>`;

export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];

/* ---------- panels ---------- */
const stack = [];
export function panel({ title, body, full = false, cls = '', scrim = true, onClose, doneLabel = 'Done' }) {
  const sc = scrim ? Object.assign(document.createElement('div'), { className: 'scrim' }) : null;
  const el = document.createElement('section');
  el.className = `panel ${full ? 'full' : ''} ${cls}`;
  el.setAttribute('role', 'dialog');
  el.setAttribute('aria-modal', scrim ? 'true' : 'false');
  el.setAttribute('aria-label', title);
  el.innerHTML = `<header class="panel-head"><h2>${esc(title)}</h2><button class="done" data-close>${esc(doneLabel)}</button></header><div class="panel-body"></div>`;
  const bodyEl = el.querySelector('.panel-body');
  if (typeof body === 'string') bodyEl.innerHTML = body; else if (body) bodyEl.append(body);
  const api = { el, body: bodyEl, close };
  function close() {
    if (api.closed) return; api.closed = true;
    el.classList.remove('on'); sc && sc.classList.remove('on');
    setTimeout(() => { el.remove(); sc && sc.remove(); }, 230);
    const i = stack.indexOf(api); if (i >= 0) stack.splice(i, 1);
    onClose && onClose();
  }
  el.querySelector('[data-close]').addEventListener('click', close);
  sc && sc.addEventListener('click', close);
  if (sc) document.body.append(sc);
  document.body.append(el);
  requestAnimationFrame(() => { el.classList.add('on'); sc && sc.classList.add('on'); });
  stack.push(api);
  return api;
}
export const topPanel = () => stack[stack.length - 1];
export function closeAllPanels() { [...stack].forEach(p => p.close()); }

/* Action menu. items: [{label, icon, danger, sub, run}] */
export function menu(title, items, subtitle) {
  const ul = document.createElement('ul'); ul.className = 'menu';
  const p = panel({ title, body: '' });
  if (subtitle) p.body.insertAdjacentHTML('afterbegin', `<div class="menu-title">${esc(subtitle)}</div>`);
  for (const it of items) {
    if (!it) continue;
    const li = document.createElement('li');
    li.innerHTML = `<button class="${it.danger ? 'danger' : ''}">${it.icon ? icon(it.icon) : ''}<span>${esc(it.label)}</span>${it.sub ? `<span class="sub">${esc(it.sub)}</span>` : ''}</button>`;
    li.firstChild.addEventListener('click', () => { p.close(); setTimeout(() => it.run(), 60); });
    ul.append(li);
  }
  p.body.append(ul);
  return p;
}

/* ---------- dialogs ---------- */
function dialog({ title, text, input, ok = 'OK', cancel = 'Cancel', danger = false }) {
  return new Promise(resolve => {
    const sc = Object.assign(document.createElement('div'), { className: 'scrim' });
    sc.style.zIndex = 59;
    const d = document.createElement('div'); d.className = 'dialog'; d.setAttribute('role', 'alertdialog');
    d.innerHTML = `<h3>${esc(title)}</h3>${text ? `<p>${esc(text)}</p>` : ''}${input !== undefined ? `<input type="text" autocomplete="off" autocapitalize="sentences" spellcheck="false">` : ''}
      <div class="acts">${cancel ? `<button data-a="c">${esc(cancel)}</button>` : ''}<button class="go ${danger ? 'danger' : ''}" data-a="o">${esc(ok)}</button></div>`;
    document.body.append(sc, d);
    const inp = d.querySelector('input');
    if (inp) { inp.value = input; setTimeout(() => { inp.focus(); inp.select(); }, 50); }
    requestAnimationFrame(() => { sc.classList.add('on'); d.classList.add('on'); });
    const done = v => { sc.remove(); d.remove(); resolve(v); };
    d.addEventListener('click', e => {
      const a = e.target.closest('[data-a]')?.dataset.a; if (!a) return;
      done(a === 'o' ? (inp ? inp.value : true) : (inp ? null : false));
    });
    inp && inp.addEventListener('keydown', e => { if (e.key === 'Enter') done(inp.value); });
    sc.addEventListener('click', () => done(inp ? null : false));
  });
}
export const ask = (title, value, ok = 'Save', text) => dialog({ title, text, input: value ?? '', ok });
export const confirmBox = (title, text, ok = 'Continue', danger = false) => dialog({ title, text, ok, danger });
export const info = (title, text) => dialog({ title, text, ok: 'OK', cancel: null });

/* ---------- toast ---------- */
let toastEl, toastT;
export function toast(msg, action) {
  if (!toastEl) { toastEl = document.createElement('div'); toastEl.className = 'toast'; toastEl.setAttribute('role', 'status'); document.body.append(toastEl); }
  toastEl.innerHTML = `<span>${esc(msg)}</span>${action ? `<button>${esc(action.label)}</button>` : ''}`;
  if (action) toastEl.querySelector('button').onclick = () => { toastEl.classList.remove('on'); action.run(); };
  toastEl.classList.add('on');
  clearTimeout(toastT); toastT = setTimeout(() => toastEl.classList.remove('on'), action ? 5000 : 2600);
}

/* ---------- formatting helpers ---------- */
const DF = new Intl.DateTimeFormat(undefined, { day: 'numeric', month: 'short' });
const DFY = new Intl.DateTimeFormat(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
const TF = new Intl.DateTimeFormat(undefined, { hour: 'numeric', minute: '2-digit' });
export function when(t) {
  const d = new Date(t), now = new Date();
  if (d.toDateString() === now.toDateString()) return 'Today, ' + TF.format(d);
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return 'Yesterday';
  return d.getFullYear() === now.getFullYear() ? DF.format(d) : DFY.format(d);
}
export const num = n => (n ?? 0).toLocaleString();
