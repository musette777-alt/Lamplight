/* ==========================================================================
   Lamplight — application
   Library · Editor · Formatting · Font library · Document settings · Switcher
   ========================================================================== */
import * as store from './store.js';
import * as fonts from './fonts.js';
import * as T from './text.js';
import { icon, esc, $, $$, panel, menu, ask, confirmBox, info, toast, when, num, topPanel } from './ui.js';

const VERSION = '0.1 · Stage 1';
const SANDBOXED = (() => { try { return window.self !== window.top; } catch (e) { return true; } })();
const STANDALONE = matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
const NARROW = () => innerWidth < 720;

const PAGE_SIZES = {
  letter: { label: 'Letter', w: 8.5, h: 11 },
  a4: { label: 'A4', w: 8.27, h: 11.69 },
  a5: { label: 'A5', w: 5.83, h: 8.27 },
  trade: { label: '6 × 9', w: 6, h: 9 },
};
const MARGIN_PRESETS = { narrow: 0.75, normal: 1, wide: 1.25 };
const PX_IN = 96, PAGE_GAP = 26;

const state = {
  docs: new Map(), folders: [],
  section: 'recent', sort: 'modified', view: 'list', query: '',
  openTabs: [], tabState: {}, current: null,
  textIndex: null,
};

/* ========================================================================
   BOOT
   ======================================================================== */
async function boot() {
  const mode = await store.open();
  await store.loadPrefs();
  try { for (const d of await store.all('docs')) state.docs.set(d.id, d); } catch (e) {}
  try { state.folders = (await store.all('folders')).sort((a, b) => a.name.localeCompare(b.name)); } catch (e) {}
  state.view = store.pref('view', 'list');
  state.sort = store.pref('sort', 'modified');
  state.section = store.pref('section', 'recent');
  state.openTabs = store.pref('openTabs', []).filter(id => state.docs.has(id) && !state.docs.get(id).deletedAt);
  state.tabState = store.pref('tabState', {});
  if (state.section.startsWith('f:') && !state.folders.some(f => 'f:' + f.id === state.section)) state.section = 'all';

  await recoverUnsaved();
  await fonts.init();
  applyUIFont();

  buildLibrary();
  buildEditorShell();
  renderLibrary();
  showNotice(mode);
  watchKeyboard();

  addEventListener('pagehide', flushSave);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flushSave(); });

  if ('serviceWorker' in navigator && !SANDBOXED && location.protocol === 'https:') {
    navigator.serviceWorker.register('sw.js').catch(e => console.warn('SW', e));
  }
}

/* The UI uses Garamond when it is available, else Crimson Pro. */
function applyUIFont() {
  document.documentElement.style.setProperty('--f-text', fonts.stackFor(fonts.isAvailable('eb-garamond') ? 'eb-garamond' : 'crimson-pro'));
  document.documentElement.style.setProperty('--f-display', fonts.stackFor(fonts.isAvailable('eb-garamond') ? 'eb-garamond' : 'crimson-pro'));
}

/* Restore any edits that reached the recovery copy but not the library (crash, forced close). */
async function recoverUnsaved() {
  for (const r of store.listRecovery()) {
    const meta = state.docs.get(r.id);
    if (!meta) { store.clearRecovery(r.id); continue; }
    if (r.t > (meta.modified || 0)) {
      const div = document.createElement('div'); div.innerHTML = r.html;
      const s = T.stats(div);
      Object.assign(meta, { modified: r.t, words: s.words, excerpt: excerptOf(s.text), preview: s.text.slice(0, 420) });
      if (meta.titleAuto) meta.title = autoTitle(s.text);
      try {
        await store.putMany([['docs', meta], ['bodies', { id: r.id, html: r.html, text: s.text }]]);
        store.clearRecovery(r.id);
        setTimeout(() => toast(`Recovered unsaved changes to “${meta.title || 'Untitled'}”`), 600);
      } catch (e) { /* keep recovery copy for next time */ }
    } else store.clearRecovery(r.id);
  }
}

function showNotice(mode) {
  const n = $('#notice');
  let msg = '';
  if (mode === 'memory') msg = '<b>Storage is unavailable here.</b> Nothing you write in this window will be kept after it closes.';
  else if (SANDBOXED && !sessionStorage.getItem?.('lp.nd')) msg = '<b>Preview copy.</b> Storage in this preview isn’t guaranteed. Install your own copy before trusting it with real work.';
  if (!msg) { n.hidden = true; return; }
  n.innerHTML = `<span>${msg}</span><button data-a="how">How</button>${mode !== 'memory' ? '<button data-a="x" aria-label="Dismiss">Hide</button>' : ''}`;
  n.hidden = false;
  n.onclick = e => {
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (a === 'how') openSettings('install');
    if (a === 'x') { try { sessionStorage.setItem('lp.nd', '1'); } catch (e) {} n.hidden = true; }
  };
}

/* ========================================================================
   DOCUMENT MODEL
   ======================================================================== */
function defaultSettings() {
  return {
    mode: store.pref('defaultMode', NARROW() ? 'continuous' : 'paged'),
    pageSize: store.pref('defaultPageSize', 'letter'),
    margins: { t: 1, b: 1, l: 1, r: 1 }, marginPreset: 'normal',
    header: '', footer: '', pageNumbers: 'footer-center', firstPageDifferent: true,
    font: store.pref('defaultFont', fonts.DEFAULT_FONT), size: 13, lineHeight: 1.5, paraSpacing: 0, firstIndent: false,
    zoom: 'fit',
  };
}
const autoTitle = text => { const l = (text || '').split('\n').map(s => s.trim()).find(Boolean) || ''; return l.length > 80 ? l.slice(0, 78).trim() + '…' : l; };
const excerptOf = text => { const lines = (text || '').split('\n').map(s => s.trim()).filter(Boolean); return (lines[1] || '').slice(0, 140); };
const titleOf = d => d.title || 'Untitled';
/* Name shown for a font choice; says plainly when a fallback is standing in. */
const fontLabel = id => { const f = fonts.byId(id); return fonts.isAvailable(f.id) ? f.name : `${f.name} (not added; using Crimson Pro)`; };

function newDocMeta(folderId = null) {
  const t = Date.now();
  return { id: store.uid(), title: '', titleAuto: true, folderId, starred: false, created: t, modified: t, opened: t,
    deletedAt: null, words: 0, excerpt: '', preview: '', settings: defaultSettings() };
}
async function saveMeta(meta) { try { await store.put('docs', meta); } catch (e) { toast('Could not save to this device'); } }

/* ========================================================================
   LIBRARY
   ======================================================================== */
function buildLibrary() {
  const lib = $('#lib');
  lib.innerHTML = `
  <div class="lib-scroll" id="libScroll"><div class="lib-inner">
    <div class="brandbar">
      <div class="wordmark" aria-label="Lamplight">Lamplight<span class="dot"></span></div>
      <div class="spacer"></div>
      <button class="iconbtn" id="btnSettings" aria-label="Settings">${icon('settings')}</button>
      <button class="avatarbtn" id="btnProfile" aria-label="Profile"><span class="avatar" id="avatar"></span></button>
    </div>
    <h1 class="lib-title"><span id="secTitle">Recent</span><small id="secCount"></small></h1>
    <label class="search">${icon('search')}<span class="sr">Search documents</span>
      <input id="q" type="text" inputmode="search" placeholder="Search titles and text" autocomplete="off" autocorrect="off" spellcheck="false" enterkeyhint="search">
      <button class="clear iconbtn" id="qClear" aria-label="Clear search" hidden>${icon('x')}</button></label>
    <nav class="shelf" id="shelf" aria-label="Library sections"></nav>
    <div class="lib-tools">
      <button class="sortbtn" id="sortBtn"><span id="sortLbl"></span>${icon('chev')}</button>
      <div class="spacer"></div>
      <div class="viewtog" role="group" aria-label="View">
        <button data-view="list" aria-label="List view">${icon('list')}</button>
        <button data-view="grid" aria-label="Grid view">${icon('grid')}</button>
      </div>
    </div>
    <div id="results"></div>
  </div></div>
  <div class="lib-bar"><div class="lib-bar-in">
    <button class="btn" id="btnNewFolder">${icon('folderplus')}<span>New Folder</span></button>
    <button class="btn primary" id="btnNew">${icon('pen')}<span>New Document</span></button>
  </div></div>`;

  $('#btnNew').onclick = () => createDocument();
  $('#btnNewFolder').onclick = () => createFolder();
  $('#btnSettings').onclick = () => openSettings();
  $('#btnProfile').onclick = () => openSettings('profile');
  $('#sortBtn').onclick = sortMenu;
  $$('.viewtog button').forEach(b => b.onclick = () => { state.view = b.dataset.view; store.setPref('view', state.view); renderLibrary(); });
  const q = $('#q');
  let qt;
  q.addEventListener('input', () => { clearTimeout(qt); qt = setTimeout(() => { state.query = q.value; renderLibrary(); }, 120); $('#qClear').hidden = !q.value; });
  $('#qClear').onclick = () => { q.value = ''; state.query = ''; $('#qClear').hidden = true; renderLibrary(); };
  $('#shelf').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.sec) { state.section = b.dataset.sec; store.setPref('section', state.section); renderLibrary(); $('#libScroll').scrollTop = 0; }
    if (b.dataset.act === 'folder') createFolder();
  });
  $('#results').addEventListener('click', onResultsClick);
  renderAvatar();
}

function renderAvatar() {
  const a = $('#avatar'); if (!a) return;
  const img = store.pref('avatar', null), name = store.pref('name', '');
  a.innerHTML = img ? `<img alt="" src="${img}">` : esc((name.trim()[0] || 'L').toUpperCase());
}

const live = () => [...state.docs.values()].filter(d => !d.deletedAt);
const trashed = () => [...state.docs.values()].filter(d => d.deletedAt);
const folderName = id => state.folders.find(f => f.id === id)?.name;

function sectionDocs() {
  const s = state.section;
  if (s === 'recent') return live().sort((a, b) => Math.max(b.opened, b.modified) - Math.max(a.opened, a.modified)).slice(0, 30);
  if (s === 'starred') return sortDocs(live().filter(d => d.starred));
  if (s === 'all') return sortDocs(live());
  if (s === 'trash') return trashed().sort((a, b) => b.deletedAt - a.deletedAt);
  if (s.startsWith('f:')) return sortDocs(live().filter(d => d.folderId === s.slice(2)));
  return [];
}
function sortDocs(arr) {
  const k = state.sort;
  if (k === 'title') return arr.sort((a, b) => titleOf(a).localeCompare(titleOf(b), undefined, { sensitivity: 'base', numeric: true }));
  if (k === 'created') return arr.sort((a, b) => b.created - a.created);
  return arr.sort((a, b) => b.modified - a.modified);
}
const SORT_LABEL = { modified: 'Last edited', created: 'Date created', title: 'Title A–Z' };
function sortMenu() {
  if (state.section === 'recent' || state.section === 'trash') return;
  menu('Sort by', Object.entries(SORT_LABEL).map(([k, l]) => ({ label: l, icon: state.sort === k ? 'check' : null, run: () => { state.sort = k; store.setPref('sort', k); renderLibrary(); } })));
}

function renderShelf() {
  const L = live(), st = L.filter(d => d.starred).length, tr = trashed().length;
  const b = (sec, label, count) => `<button data-sec="${sec}" aria-pressed="${state.section === sec}">${esc(label)}${count != null ? ` <span class="count">${count}</span>` : ''}</button>`;
  $('#shelf').innerHTML = b('recent', 'Recent') + b('starred', 'Starred', st || null) + b('all', 'My Documents', L.length) +
    state.folders.map(f => b('f:' + f.id, f.name, L.filter(d => d.folderId === f.id).length)).join('') +
    b('trash', 'Trash', tr || null) + `<button class="addfolder" data-act="folder" aria-label="New folder">${icon('plus')}</button>`;
  const cur = $('#shelf [aria-pressed="true"]'); cur && cur.scrollIntoView({ inline: 'nearest', block: 'nearest' });
}

async function renderLibrary() {
  renderShelf();
  $$('.viewtog button').forEach(b => b.setAttribute('aria-pressed', b.dataset.view === state.view));
  const s = state.section, r = $('#results');
  const titles = { recent: 'Recent', starred: 'Starred', all: 'My Documents', trash: 'Trash' };
  let docs, hits = null;
  if (state.query.trim()) {
    $('#secTitle').textContent = 'Search';
    hits = await search(state.query);
    docs = hits.map(h => h.doc);
  } else {
    $('#secTitle').textContent = titles[s] || folderName(s.slice(2)) || 'Folder';
    docs = sectionDocs();
  }
  $('#secCount').textContent = docs.length ? num(docs.length) : '';
  $('#sortLbl').textContent = hits ? 'Best match' : s === 'recent' ? 'Most recent first' : s === 'trash' ? 'Recently deleted' : `Sorted by ${SORT_LABEL[state.sort]}`;
  $('#sortBtn').querySelector('svg').style.visibility = (hits || s === 'recent' || s === 'trash') ? 'hidden' : '';

  let head = '';
  if (!hits && s === 'trash' && docs.length) head = `<div class="trashnote">Documents stay here until you delete them permanently.<button data-act="empty">Empty Trash</button></div>`;
  if (!hits && s.startsWith('f:')) head = `<div class="trashnote">Folder<button data-act="folder-menu" data-id="${s.slice(2)}">Folder options</button></div>`;

  if (!docs.length) {
    const msg = hits ? ['Nothing found', 'Try fewer words, or put an exact phrase in “quotes”.'] :
      s === 'trash' ? ['Trash is empty', ''] : s === 'starred' ? ['No starred documents', 'Star a document from its ⋯ menu.'] :
      state.docs.size ? ['Nothing here yet', ''] : ['A blank page is waiting', 'Tap New Document to begin.'];
    r.innerHTML = head + `<div class="empty"><div class="e1">${msg[0]}</div><div class="e2">${msg[1]}</div></div>`;
    return;
  }
  const showFolder = s !== 'trash' && !s.startsWith('f:');
  const meta = (d) => {
    const parts = [`${num(d.words)} ${d.words === 1 ? 'word' : 'words'}`, s === 'trash' ? `Deleted ${when(d.deletedAt)}` : (state.sort === 'created' && s !== 'recent' ? `Created ${when(d.created)}` : `Edited ${when(d.modified)}`)];
    if (showFolder && d.folderId && folderName(d.folderId)) parts.push(folderName(d.folderId));
    return parts.map(esc).join('<i>·</i>');
  };
  if (state.view === 'grid' && !hits) {
    r.innerHTML = head + `<ul class="docgrid">${docs.map(d => `
      <li class="sheetcard"><button class="open" data-id="${d.id}" aria-label="Open ${esc(titleOf(d))}">
        <div class="sheet-paper">${d.starred ? '<span class="star">★</span>' : ''}<div class="t">${esc(titleOf(d))}</div><div class="b">${esc(previewBody(d))}</div></div></button>
        <div class="cap"><div class="txt"><div class="nm">${esc(titleOf(d))}</div><div class="mt">${meta(d)}</div></div>
        <button class="more" data-more="${d.id}" aria-label="Options for ${esc(titleOf(d))}">${icon('more')}</button></div></li>`).join('')}</ul>`;
  } else {
    r.innerHTML = head + `<ul class="doclist">${docs.map((d, i) => `
      <li class="docrow"><button class="open" data-id="${d.id}">
        <div class="doc-title ${d.title ? '' : 'untitled'}">${d.starred ? '<span class="star" aria-label="Starred">★</span>' : ''}<span>${hits ? hits[i].titleHTML : esc(titleOf(d))}</span></div>
        ${hits ? (hits[i].snippet ? `<div class="doc-excerpt">${hits[i].snippet}</div>` : '') : d.excerpt ? `<div class="doc-excerpt">${esc(d.excerpt)}</div>` : ''}
        <div class="doc-meta">${meta(d)}</div></button>
        <button class="more" data-more="${d.id}" aria-label="Options for ${esc(titleOf(d))}">${icon('more')}</button></li>`).join('')}</ul>`;
  }
}
function previewBody(d) {
  const p = (d.preview || '').split('\n');
  if (p.length && p[0].trim() === (d.title || '').replace(/…$/, '').trim()) p.shift();
  return p.join('\n').trim();
}

function onResultsClick(e) {
  const o = e.target.closest('.open'); if (o) return openDocument(o.dataset.id);
  const m = e.target.closest('[data-more]'); if (m) return docMenu(m.dataset.more);
  const a = e.target.closest('[data-act]');
  if (a?.dataset.act === 'empty') emptyTrash();
  if (a?.dataset.act === 'folder-menu') folderMenu(a.dataset.id);
}

function docMenu(id) {
  const d = state.docs.get(id); if (!d) return;
  if (d.deletedAt) {
    return menu(titleOf(d), [
      { label: 'Restore', icon: 'restore', run: () => restoreDoc(id) },
      { label: 'Delete Permanently', icon: 'trash', danger: true, run: () => purgeDocs([id]) },
    ]);
  }
  menu(titleOf(d), [
    { label: 'Open', icon: 'doc', run: () => openDocument(id) },
    { label: 'Rename', icon: 'rename', run: () => renameDoc(id) },
    { label: d.starred ? 'Unstar' : 'Star', icon: 'star', run: () => toggleStar(id) },
    { label: 'Duplicate', icon: 'copy', run: () => duplicateDoc(id) },
    { label: 'Move to Folder', icon: 'move', sub: folderName(d.folderId) || 'My Documents', run: () => moveDoc(id) },
    { label: 'Move to Trash', icon: 'trash', danger: true, run: () => trashDoc(id) },
  ], `${num(d.words)} words · created ${when(d.created)}`);
}

async function renameDoc(id) {
  const d = state.docs.get(id);
  const v = await ask('Rename', d.title || '', 'Rename');
  if (v === null) return;
  d.title = v.trim(); d.titleAuto = !d.title;
  if (d.titleAuto && state.current?.id === id) d.title = autoTitle(T.plainText(edDoc()));
  await saveMeta(d); renderLibrary(); if (state.current?.id === id) renderEdTitle();
}
async function toggleStar(id) { const d = state.docs.get(id); d.starred = !d.starred; await saveMeta(d); renderLibrary(); toast(d.starred ? 'Starred' : 'Unstarred'); }
async function duplicateDoc(id) {
  if (state.current?.id === id) await flushSave();
  const src = state.docs.get(id), body = (await store.get('bodies', id)) || { html: '', text: '' };
  const t = Date.now();
  const copy = { ...structuredClone(src), id: store.uid(), title: (src.title || 'Untitled') + ' (copy)', titleAuto: false, created: t, modified: t, opened: t, starred: false };
  state.docs.set(copy.id, copy);
  try { await store.putMany([['docs', copy], ['bodies', { id: copy.id, html: body.html, text: body.text }]]); } catch (e) { toast('Could not save the copy'); }
  state.textIndex?.set(copy.id, body.text || '');
  renderLibrary(); toast('Duplicated');
}
function moveDoc(id) {
  const d = state.docs.get(id);
  menu('Move to', [
    { label: 'My Documents (no folder)', icon: d.folderId ? 'folder' : 'check', run: () => setFolder(id, null) },
    ...state.folders.map(f => ({ label: f.name, icon: d.folderId === f.id ? 'check' : 'folder', run: () => setFolder(id, f.id) })),
    { label: 'New Folder…', icon: 'folderplus', run: async () => { const f = await createFolder(true); if (f) setFolder(id, f.id); } },
  ]);
}
async function setFolder(id, fid) { const d = state.docs.get(id); d.folderId = fid; await saveMeta(d); renderLibrary(); toast(`Moved to ${folderName(fid) || 'My Documents'}`); }
async function trashDoc(id) {
  const d = state.docs.get(id); if (state.current?.id === id) { await flushSave(); closeTab(id, true); }
  d.deletedAt = Date.now(); await saveMeta(d);
  state.openTabs = state.openTabs.filter(x => x !== id); store.setPref('openTabs', state.openTabs);
  renderLibrary();
  toast('Moved to Trash', { label: 'Undo', run: () => restoreDoc(id) });
}
async function restoreDoc(id) { const d = state.docs.get(id); d.deletedAt = null; await saveMeta(d); renderLibrary(); toast('Restored'); }
async function purgeDocs(ids) {
  const ok = await confirmBox(ids.length > 1 ? `Delete ${ids.length} documents?` : 'Delete permanently?', 'This cannot be undone. The text will be removed from this device.', 'Delete', true);
  if (!ok) return;
  try { await store.delMany(ids.flatMap(id => [['docs', id], ['bodies', id]])); } catch (e) { return toast('Could not delete'); }
  ids.forEach(id => { state.docs.delete(id); state.textIndex?.delete(id); store.clearRecovery(id); });
  renderLibrary(); toast('Deleted');
}
const emptyTrash = () => purgeDocs(trashed().map(d => d.id));

async function createFolder(returnIt) {
  const name = await ask('New Folder', '', 'Create');
  if (!name || !name.trim()) return null;
  const f = { id: store.uid(), name: name.trim(), created: Date.now() };
  state.folders.push(f); state.folders.sort((a, b) => a.name.localeCompare(b.name));
  try { await store.put('folders', f); } catch (e) {}
  if (!returnIt) { state.section = 'f:' + f.id; store.setPref('section', state.section); }
  renderLibrary();
  return f;
}
function folderMenu(fid) {
  const f = state.folders.find(x => x.id === fid); if (!f) return;
  menu(f.name, [
    { label: 'Rename Folder', icon: 'rename', run: async () => { const v = await ask('Rename Folder', f.name, 'Rename'); if (v && v.trim()) { f.name = v.trim(); await store.put('folders', f); renderLibrary(); } } },
    { label: 'Delete Folder', icon: 'trash', danger: true, run: async () => {
      const n = live().filter(d => d.folderId === fid).length;
      if (!await confirmBox('Delete folder?', n ? `Its ${n} document${n > 1 ? 's' : ''} will move to My Documents. Nothing is deleted.` : 'The folder is empty.', 'Delete Folder', true)) return;
      for (const d of state.docs.values()) if (d.folderId === fid) { d.folderId = null; await saveMeta(d); }
      await store.delMany([['folders', fid]]); state.folders = state.folders.filter(x => x.id !== fid);
      state.section = 'all'; renderLibrary();
    } },
  ]);
}

/* ---------- search (local, offline) ---------- */
const fold = s => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
async function buildIndex() {
  state.textIndex = new Map();
  try { for (const b of await store.all('bodies')) state.textIndex.set(b.id, b.text || ''); } catch (e) {}
}
function parseQuery(q) {
  const terms = []; q.replace(/"([^"]+)"|“([^”]+)”|(\S+)/g, (_, a, b, c) => { const t = fold((a || b || c).trim()); if (t) terms.push(t); });
  return terms;
}
async function search(q) {
  if (!state.textIndex) await buildIndex();
  const terms = parseQuery(q); if (!terms.length) return [];
  const out = [];
  for (const d of live()) {
    const title = titleOf(d), ft = fold(title), text = state.textIndex.get(d.id) || '', fx = fold(text);
    if (!terms.every(t => ft.includes(t) || fx.includes(t))) continue;
    const score = terms.reduce((s, t) => s + (ft.includes(t) ? 10 : 0) + Math.min(5, fx.split(t).length - 1), 0);
    out.push({ doc: d, score, titleHTML: highlight(title, terms), snippet: snippet(text, fx, terms) });
  }
  return out.sort((a, b) => b.score - a.score || b.doc.modified - a.doc.modified);
}
function highlight(s, terms) {
  // fold() keeps string length for precomposed Latin, so indices map back.
  const f = fold(s); const marks = [];
  for (const t of terms) { let i = 0; while ((i = f.indexOf(t, i)) >= 0) { marks.push([i, i + t.length]); i += t.length; } }
  if (!marks.length || f.length !== s.length) return esc(s);
  marks.sort((a, b) => a[0] - b[0]);
  let out = '', p = 0;
  for (const [a, b] of marks) { if (a < p) continue; out += esc(s.slice(p, a)) + '<mark class="hit">' + esc(s.slice(a, b)) + '</mark>'; p = b; }
  return out + esc(s.slice(p));
}
function snippet(text, ftext, terms) {
  let pos = -1; for (const t of terms) { const i = ftext.indexOf(t); if (i >= 0 && (pos < 0 || i < pos)) pos = i; }
  if (pos < 0) return '';
  const a = Math.max(0, pos - 50), b = Math.min(text.length, pos + 90);
  const s = (a ? '…' : '') + text.slice(a, b).replace(/\s+/g, ' ') + (b < text.length ? '…' : '');
  return highlight(s, terms);
}

/* ========================================================================
   EDITOR
   ======================================================================== */
let saveTimer = null, saveMaxTimer = null, dirty = false, saving = null, paginateTimer = null, savedRange = null;
const edDoc = () => $('#doc');

function buildEditorShell() {
  const ed = $('#ed');
  ed.innerHTML = `
  <header class="ed-top">
    <button class="backbtn" id="edBack">${icon('back')}<span>Library</span></button>
    <div class="ed-titlewrap"><button class="ed-title" id="edTitle" aria-label="Rename document"></button>
      <div class="ed-sub"><button id="edCount" aria-label="Document statistics"></button><i>·</i><span class="savestate" id="saveState" role="status" aria-live="polite">Saved</span></div></div>
    <button class="tabsbtn" id="edTabs" aria-label="Open documents"><span class="tc" id="edTabCount">1</span></button>
    <button class="iconbtn" id="edMenu" aria-label="Document options">${icon('more')}</button>
  </header>
  <div class="ed-canvas" id="canvas"></div>
  <div class="toolbar" id="toolbar" hidden role="toolbar" aria-label="Formatting">
    <div class="scroller">
      <button class="tb aa" data-cmd="panel" aria-label="Text formatting">Aa</button>
      <span class="tbsep"></span>
      <button class="tb" data-cmd="bold" aria-label="Bold">${icon('bold')}</button>
      <button class="tb" data-cmd="italic" aria-label="Italic">${icon('italic')}</button>
      <button class="tb" data-cmd="underline" aria-label="Underline">${icon('underline')}</button>
      <span class="tbsep"></span>
      <button class="tb" data-cmd="insertUnorderedList" aria-label="Bulleted list">${icon('ul')}</button>
      <button class="tb" data-cmd="insertOrderedList" aria-label="Numbered list">${icon('ol')}</button>
      <button class="tb" data-cmd="align-cycle" aria-label="Alignment" id="tbAlign">${icon('al')}</button>
      <span class="tbsep"></span>
      <button class="tb" data-cmd="undo" aria-label="Undo">${icon('undo')}</button>
      <button class="tb" data-cmd="redo" aria-label="Redo">${icon('redo')}</button>
      <button class="tb" data-cmd="pagebreak" aria-label="Insert page break">${icon('pagebreak')}</button>
    </div>
    <button class="tb done" data-cmd="done">Done</button>
  </div>`;

  $('#edBack').onclick = () => leaveEditor();
  $('#edTitle').onclick = () => state.current && renameDoc(state.current.id);
  $('#edTabs').onclick = openSwitcher;
  $('#edMenu').onclick = editorMenu;
  $('#edCount').onclick = openStats;

  const tb = $('#toolbar');
  // keep the caret: buttons must not steal focus from the page
  tb.addEventListener('pointerdown', e => { if (e.target.closest('button')) e.preventDefault(); });
  tb.addEventListener('mousedown', e => e.preventDefault());
  tb.addEventListener('click', e => { const b = e.target.closest('[data-cmd]'); if (b) toolbarCmd(b.dataset.cmd); });

  document.addEventListener('selectionchange', onSelectionChange);
}

async function createDocument() {
  const fid = state.section.startsWith('f:') ? state.section.slice(2) : null;
  const meta = newDocMeta(fid);
  state.docs.set(meta.id, meta);
  // open synchronously so iOS raises the keyboard inside this tap
  openEditor(meta, '', { focus: true });
  try { await store.putMany([['docs', meta], ['bodies', { id: meta.id, html: '', text: '' }]]); setSaveState('saved'); }
  catch (e) { setSaveState('error'); }
  store.requestPersistence();
}

async function openDocument(id) {
  const meta = state.docs.get(id); if (!meta || meta.deletedAt) return;
  if (state.current && state.current.id !== id) await leaveCurrent();
  let body = null;
  try { body = await store.get('bodies', id); } catch (e) {}
  openEditor(meta, body?.html || '', {});
}

function openEditor(meta, html, { focus }) {
  meta.settings = { ...defaultSettings(), ...(meta.settings || {}) };
  meta.opened = Date.now(); saveMeta(meta);
  state.current = meta;
  if (!state.openTabs.includes(meta.id)) { state.openTabs.unshift(meta.id); state.openTabs = state.openTabs.slice(0, 12); }
  store.setPref('openTabs', state.openTabs);

  $('#lib').setAttribute('aria-hidden', 'true');
  $('#ed').setAttribute('aria-hidden', 'false');
  $('#notice').hidden = true;

  const canvas = $('#canvas');
  canvas.innerHTML = '';
  const doc = document.createElement('div');
  doc.id = 'doc'; doc.className = 'doc';
  doc.contentEditable = 'true';
  doc.setAttribute('role', 'textbox'); doc.setAttribute('aria-multiline', 'true'); doc.setAttribute('aria-label', 'Document');
  doc.setAttribute('spellcheck', 'true'); doc.setAttribute('autocapitalize', 'sentences');
  doc.dataset.placeholder = 'Begin writing';
  doc.innerHTML = html || '<p><br></p>';
  doc.addEventListener('input', onInput);
  doc.addEventListener('paste', onPaste);
  doc.addEventListener('focus', () => showToolbar(true));
  doc.addEventListener('blur', () => setTimeout(() => { if (document.activeElement !== edDoc() && !$('.panel.format')) showToolbar(false); }, 120));
  doc.addEventListener('keydown', e => {
    if ((e.metaKey || e.ctrlKey) && !e.shiftKey && ['b', 'i', 'u'].includes(e.key.toLowerCase())) { e.preventDefault(); exec({ b: 'bold', i: 'italic', u: 'underline' }[e.key.toLowerCase()]); }
  });
  try { document.execCommand('defaultParagraphSeparator', false, 'p'); } catch (e) {}

  layoutCanvas(doc);
  renderEdTitle(); updateCounts(); setSaveState('saved');
  $('#edTabCount').textContent = state.openTabs.length;

  const ts = state.tabState[meta.id];
  requestAnimationFrame(() => {
    if (ts) { canvas.scrollTop = ts.scroll || 0; }
    if (focus) { placeCaretAtOffset(doc, 0); doc.focus({ preventScroll: true }); }
    else if (ts && ts.caret != null) placeCaretAtOffset(doc, ts.caret, true);
  });
  if (focus) { placeCaretAtOffset(doc, 0); doc.focus({ preventScroll: true }); }
}

/* --- canvas: continuous or paged --- */
function layoutCanvas(doc = edDoc()) {
  const s = state.current.settings, canvas = $('#canvas');
  const scroll = canvas.scrollTop;
  canvas.className = 'ed-canvas ' + s.mode;
  applyDocVars();
  doc.classList.toggle('indent-first', !!s.firstIndent);
  canvas.innerHTML = '';
  if (s.mode === 'paged') {
    canvas.innerHTML = `<div class="pagesbox"><div class="pagezoom" id="pagezoom"><div class="pagestack" id="pagestack"></div></div></div>`;
    $('#pagezoom').append(doc);
    applyZoom();
    paginate();
  } else {
    clearPushes(doc);
    const sh = document.createElement('div'); sh.className = 'sheet'; sh.append(doc); canvas.append(sh);
  }
  canvas.scrollTop = scroll;
}
function applyDocVars() {
  const s = state.current.settings, c = $('#canvas').style;
  c.setProperty('--doc-font', fonts.stackFor(s.font));
  c.setProperty('--doc-size', s.size + 'pt');
  c.setProperty('--doc-lh', s.lineHeight);
  c.setProperty('--doc-ps', s.paraSpacing + 'em');
  const ps = PAGE_SIZES[s.pageSize] || PAGE_SIZES.letter;
  c.setProperty('--page-w', ps.w * PX_IN + 'px'); c.setProperty('--page-h', ps.h * PX_IN + 'px');
  for (const k of ['t', 'b', 'l', 'r']) c.setProperty('--m-' + k, s.margins[k] * PX_IN + 'px');
}
function applyZoom() {
  const s = state.current.settings, z = $('#pagezoom'); if (!z) return;
  const ps = PAGE_SIZES[s.pageSize] || PAGE_SIZES.letter;
  const avail = $('#canvas').clientWidth - 24;
  const factor = s.zoom === 'fit' ? Math.min(1.25, avail / (ps.w * PX_IN)) : +s.zoom;
  z.style.zoom = factor;
}
addEventListener('resize', () => { if (state.current?.settings.mode === 'paged') { applyZoom(); schedulePaginate(); } });

function clearPushes(doc) {
  for (const el of doc.querySelectorAll('[data-push]')) { el.removeAttribute('data-push'); el.style.removeProperty('margin-top'); if (!el.getAttribute('style')) el.removeAttribute('style'); }
}
/* Block-level pagination: a paragraph that would cross a page bottom moves to the next page.
   Positions are read once, then the shifts are simulated (one layout pass). */
function paginate() {
  const doc = edDoc(), stack = $('#pagestack'); if (!doc || !stack) return;
  const s = state.current.settings, ps = PAGE_SIZES[s.pageSize] || PAGE_SIZES.letter;
  const H = ps.h * PX_IN, mt = s.margins.t * PX_IN, mb = s.margins.b * PX_IN, stride = H + PAGE_GAP;
  clearPushes(doc);
  const blocks = [...doc.children];
  const geo = blocks.map(el => ({ el, top: el.offsetTop, h: el.offsetHeight, m: parseFloat(getComputedStyle(el).marginTop) || 0, pb: el.matches('hr.pb') }));
  let shift = 0, page = 0, breakNext = false;
  const bottom = p => p * stride + H - mb, nextTop = p => (p + 1) * stride + mt;
  for (const g of geo) {
    let t = g.top + shift;
    while (t >= bottom(page) + mb) page++;                 // already on a later page
    let delta = 0;
    if (breakNext) { delta = nextTop(page) - t; page++; breakNext = false; }
    else if (t + g.h > bottom(page) && t < bottom(page) && g.h <= H - mt - mb && t > page * stride + mt + 1) { delta = nextTop(page) - t; page++; }
    else if (t < page * stride + mt && page > 0) { delta = page * stride + mt - t; }   // fell into a gap
    if (delta > 0) {
      g.el.dataset.push = '1';
      g.el.style.setProperty('margin-top', (g.m + delta) + 'px', 'important');
      shift += delta;
    }
    if (g.pb) breakNext = true;
    t = g.top + shift;
    while (t + g.h > bottom(page) + mb) page++;            // overly tall block flows on
  }
  const pages = Math.max(1, page + 1);
  doc.style.minHeight = (pages * stride - PAGE_GAP) + 'px';
  state.pageCount = pages;
  // draw the sheets
  const showNum = s.pageNumbers;
  let html = '';
  for (let i = 0; i < pages; i++) {
    const first = i === 0 && s.firstPageDifferent;
    const n = i + 1;
    const hdr = !first && (s.header || showNum === 'header-right') ? `<div class="hdr"><span>${esc(s.header)}</span>${showNum === 'header-right' ? `<span class="r">${n}</span>` : ''}</div>` : '';
    const fnum = !first && showNum === 'footer-center' ? `<span class="c">${n}</span>` : !first && showNum === 'footer-right' ? `<span class="r">${n}</span>` : '';
    const ftr = !first && (s.footer || fnum) ? `<div class="ftr">${s.footer ? `<span>${esc(s.footer)}</span>` : (showNum === 'footer-center' ? '<span></span>' : '')}${fnum}${showNum === 'footer-center' ? '<span></span>' : ''}</div>` : '';
    html += `<div class="pagesheet" style="top:${i * stride}px">${hdr}${ftr}</div>`;
  }
  stack.innerHTML = html;
  updateCounts();
}
function schedulePaginate() { clearTimeout(paginateTimer); paginateTimer = setTimeout(() => requestAnimationFrame(paginate), 140); }

/* --- input & saving --- */
function onInput() {
  dirty = true;
  const doc = edDoc();
  if (!doc.firstElementChild) doc.innerHTML = '<p><br></p>';
  // wrap stray top-level text in a paragraph
  for (const n of [...doc.childNodes]) if (n.nodeType === 3 && n.nodeValue.trim()) { const p = document.createElement('p'); n.replaceWith(p); p.append(n); placeCaretEnd(p); }
  store.writeRecovery(state.current.id, serialize());
  setSaveState('saving');
  clearTimeout(saveTimer); saveTimer = setTimeout(commitSave, 450);
  if (!saveMaxTimer) saveMaxTimer = setTimeout(commitSave, 2500);
  updateCountsSoon();
  if (state.current.settings.mode === 'paged') schedulePaginate();
}
function serialize() {
  const c = edDoc().cloneNode(true);
  for (const el of c.querySelectorAll('[data-push]')) { el.removeAttribute('data-push'); el.style.removeProperty('margin-top'); }
  for (const el of c.querySelectorAll('[style]')) if (!el.getAttribute('style').trim()) el.removeAttribute('style');
  c.style.removeProperty('min-height');
  return c.innerHTML.replace(/​/g, '').replace(/<span[^>]*><\/span>/g, '');
}
async function commitSave() {
  clearTimeout(saveTimer); clearTimeout(saveMaxTimer); saveMaxTimer = null;
  if (!dirty || !state.current) return saving;
  const meta = state.current, html = serialize();
  const div = document.createElement('div'); div.innerHTML = html;
  const s = T.stats(div);
  dirty = false;
  meta.modified = Date.now(); meta.words = s.words; meta.excerpt = excerptOf(s.text); meta.preview = s.text.slice(0, 420);
  if (meta.titleAuto) { meta.title = autoTitle(s.text); renderEdTitle(); }
  const job = store.putMany([['docs', meta], ['bodies', { id: meta.id, html, text: s.text }]])
    .then(() => { state.textIndex?.set(meta.id, s.text); if (!dirty) { store.clearRecovery(meta.id); setSaveState('saved'); } })
    .catch(e => { console.error(e); dirty = true; setSaveState('error'); });
  saving = job;
  return job;
}
async function flushSave() { if (dirty) await commitSave(); else if (saving) await saving; }

function setSaveState(st) {
  const el = $('#saveState'); if (!el) return;
  el.className = 'savestate ' + (st === 'saving' ? 'saving' : st === 'error' ? 'error' : '');
  el.textContent = st === 'saving' ? 'Saving…' : st === 'error' ? 'Not saved' : (store.storageMode() === 'memory' ? 'Memory only' : 'Saved');
  el.title = st === 'error' ? (store.storageMode() === 'memory' ? 'This window has no storage; nothing will be kept.' : 'Could not write to storage. Retrying; a recovery copy is kept.') : st === 'saving' ? 'Writing to this device' : 'Saved on this device';
  if (st === 'error') toast(store.storageMode() === 'memory' ? 'Storage unavailable: this writing will not be kept' : 'Could not save. Retrying, and a recovery copy is kept.');
  if (st === 'error' && store.storageMode() !== 'memory') { clearTimeout(saveTimer); saveTimer = setTimeout(commitSave, 3000); }
}

function onPaste(e) {
  const cd = e.clipboardData; if (!cd) return;
  e.preventDefault();
  const html = cd.getData('text/html'), text = cd.getData('text/plain');
  const clean = html ? T.sanitizeHTML(html) : T.textToHTML(text);
  if (/^<p>[^<]*<\/p>$/.test(clean) && !html) document.execCommand('insertText', false, text);
  else document.execCommand('insertHTML', false, clean);
}

/* --- counts --- */
let countTimer;
function updateCountsSoon() { clearTimeout(countTimer); countTimer = setTimeout(updateCounts, 250); }
function updateCounts() {
  const doc = edDoc(); if (!doc) return;
  const w = T.countWords(T.plainText(doc));
  const selW = selectionWords();
  $('#edCount').textContent = selW ? `${num(selW)} of ${num(w)} words` : `${num(w)} ${w === 1 ? 'word' : 'words'}${state.current.settings.mode === 'paged' && state.pageCount ? ` · ${state.pageCount} ${state.pageCount === 1 ? 'page' : 'pages'}` : ''}`;
  doc.classList.toggle('is-empty', !doc.textContent.replace(/​/g, '').length && doc.children.length <= 1 && !doc.querySelector('hr,li'));
}
function selectionWords() {
  const sel = getSelection(); if (!sel.rangeCount || sel.isCollapsed) return 0;
  const doc = edDoc(); if (!doc || !doc.contains(sel.anchorNode)) return 0;
  return T.countWords(sel.toString());
}

function renderEdTitle() {
  const t = $('#edTitle'), d = state.current; if (!t || !d) return;
  t.textContent = titleOf(d); t.classList.toggle('untitled', !d.title);
  document.title = (d.title ? d.title + ' · ' : '') + 'Lamplight';
}

/* --- leaving & tabs --- */
function rememberPosition() {
  const doc = edDoc(); if (!doc || !state.current) return;
  state.tabState[state.current.id] = { scroll: $('#canvas').scrollTop, caret: caretOffset(doc) };
  store.setPref('tabState', state.tabState);
}
async function leaveCurrent() {
  if (!state.current) return;
  rememberPosition();
  await flushSave();
  const m = state.current;
  // a new document left blank is discarded rather than cluttering the library
  if (m.titleAuto && !m.words && !(edDoc()?.textContent || '').replace(/​/g, '').trim()) {
    state.docs.delete(m.id); state.openTabs = state.openTabs.filter(x => x !== m.id); store.setPref('openTabs', state.openTabs);
    try { await store.delMany([['docs', m.id], ['bodies', m.id]]); } catch (e) {}
    store.clearRecovery(m.id);
  }
  state.current = null;
}
async function leaveEditor() {
  edDoc()?.blur();
  await leaveCurrent();
  showToolbar(false);
  $('#ed').setAttribute('aria-hidden', 'true');
  $('#lib').setAttribute('aria-hidden', 'false');
  document.title = 'Lamplight';
  showNotice(store.storageMode());
  renderLibrary();
}
async function closeTab(id, silent) {
  state.openTabs = state.openTabs.filter(x => x !== id); store.setPref('openTabs', state.openTabs);
  delete state.tabState[id]; store.setPref('tabState', state.tabState);
  if (state.current?.id === id) {
    const next = state.openTabs[0];
    if (next && !silent) { await leaveCurrent(); openDocument(next); }
    else if (!silent) leaveEditor();
  }
  $('#edTabCount') && ($('#edTabCount').textContent = state.openTabs.length);
}

function openSwitcher() {
  rememberPosition(); edDoc()?.blur();
  const p = panel({ title: 'Open Documents', full: true });
  const draw = () => {
    const tabs = state.openTabs.map(id => state.docs.get(id)).filter(Boolean);
    p.body.innerHTML = `<ul class="tablist">${tabs.map(d => `
      <li class="tabcard ${state.current?.id === d.id ? 'current' : ''}">
        <button class="open" data-id="${d.id}"><div class="sheet-paper"><div class="t">${esc(titleOf(d))}</div><div class="b">${esc(previewBody(d))}</div></div>
        <div class="nm">${esc(titleOf(d))}</div><div class="mt">${num(d.words)} words · ${when(d.modified)}</div></button>
        <button class="close" data-close-tab="${d.id}" aria-label="Close ${esc(titleOf(d))}"><span>${icon('x')}</span></button></li>`).join('')}
      <li class="tabcard"><button class="open" data-new="1"><div class="sheet-paper" style="display:grid;place-items:center;background:transparent;box-shadow:inset 0 0 0 1px var(--rule)">${icon('plus')}</div><div class="nm">New Document</div><div class="mt">&nbsp;</div></button></li>
      </ul><div style="margin-top:28px"><button class="btn small" data-lib="1">${icon('back')}<span>Library</span></button></div>`;
  };
  draw();
  p.body.addEventListener('click', async e => {
    const c = e.target.closest('[data-close-tab]');
    if (c) { await closeTab(c.dataset.closeTab, state.current?.id === c.dataset.closeTab ? false : true); if (!state.openTabs.length) { p.close(); return; } draw(); $('#edTabCount').textContent = state.openTabs.length; return; }
    const o = e.target.closest('[data-id]');
    if (o) { p.close(); if (o.dataset.id !== state.current?.id) openDocument(o.dataset.id); return; }
    if (e.target.closest('[data-new]')) { p.close(); await leaveCurrent(); createDocument(); return; }
    if (e.target.closest('[data-lib]')) { p.close(); leaveEditor(); }
  });
}

function editorMenu() {
  const d = state.current; if (!d) return;
  const s = d.settings;
  rememberPosition(); edDoc()?.blur();
  menu(titleOf(d), [
    { label: 'Document Settings', icon: 'page', run: openDocSettings },
    { label: s.mode === 'paged' ? 'Switch to Continuous' : 'Switch to Paged', icon: 'doc', sub: s.mode === 'paged' ? 'Paged' : 'Continuous', run: () => setDocSetting('mode', s.mode === 'paged' ? 'continuous' : 'paged') },
    { label: 'Document Font', icon: 'type', sub: fontLabel(s.font), run: () => openFontLibrary('document') },
    { label: 'Statistics', icon: 'stats', run: openStats },
    { label: 'Rename', icon: 'rename', run: () => renameDoc(d.id) },
    { label: d.starred ? 'Unstar' : 'Star', icon: 'star', run: () => toggleStar(d.id) },
    { label: 'Close Document', icon: 'x', run: () => closeTab(d.id) },
  ]);
}

/* ========================================================================
   FORMATTING
   ======================================================================== */
function onSelectionChange() {
  const doc = edDoc(); if (!doc) return;
  const sel = getSelection();
  if (sel.rangeCount && doc.contains(sel.anchorNode)) {
    savedRange = sel.getRangeAt(0).cloneRange();
    updateToolbarState();
    updateCountsSoon();
    formatPanelRefresh?.();
  }
}
function restoreSelection() {
  const doc = edDoc(); if (!doc) return false;
  const sel = getSelection();
  // already focused with a live selection in the page: leave it alone (re-adding a
  // range would discard pending typing styles such as a just-toggled bold)
  if (document.activeElement === doc && sel.rangeCount && doc.contains(sel.anchorNode)) return true;
  if (document.activeElement !== doc) doc.focus({ preventScroll: true });
  if (savedRange && doc.contains(savedRange.startContainer)) { sel.removeAllRanges(); sel.addRange(savedRange); }
  else if (!sel.rangeCount || !doc.contains(sel.anchorNode)) placeCaretEnd(doc);
  return true;
}
function exec(cmd, val = null) {
  restoreSelection();
  try { document.execCommand('styleWithCSS', false, cmd === 'hiliteColor' || cmd === 'foreColor'); } catch (e) {}
  document.execCommand(cmd, false, val);
  afterFormat();
}
function afterFormat() { onInput(); updateToolbarState(); formatPanelRefresh?.(); }

function toolbarCmd(cmd) {
  if (cmd === 'panel') return toggleFormatPanel();
  if (cmd === 'done') { closeFormatPanel(); edDoc()?.blur(); showToolbar(false); return; }
  if (cmd === 'pagebreak') { restoreSelection(); document.execCommand('insertHTML', false, '<hr class="pb"><p><br></p>'); afterFormat(); toast('Page break inserted'); return; }
  if (cmd === 'align-cycle') {
    const order = ['left', 'center', 'right', 'justify'];
    const cur = currentAlign(); setAlign(order[(order.indexOf(cur) + 1) % 4]); return;
  }
  exec(cmd);
}
const ALIGN_CMD = { left: 'justifyLeft', center: 'justifyCenter', right: 'justifyRight', justify: 'justifyFull' };
function setAlign(a) { exec(ALIGN_CMD[a]); }
function currentBlock() {
  const sel = getSelection(), doc = edDoc(); if (!sel.rangeCount || !doc) return null;
  let n = sel.anchorNode; if (!doc.contains(n)) return null;
  if (n.nodeType === 3) n = n.parentNode;
  return n.closest('p,h1,h2,h3,blockquote,li') || null;
}
function currentAlign() {
  const b = currentBlock(); if (!b) return 'left';
  const a = getComputedStyle(b).textAlign; return a === 'start' ? 'left' : a === 'end' ? 'right' : a;
}
function updateToolbarState() {
  const tb = $('#toolbar'); if (!tb || tb.hidden) return;
  for (const c of ['bold', 'italic', 'underline', 'insertUnorderedList', 'insertOrderedList']) {
    let on = false; try { on = document.queryCommandState(c); } catch (e) {}
    const b = tb.querySelector(`[data-cmd="${c}"]`); b && b.setAttribute('aria-pressed', on);
  }
  const a = currentAlign();
  $('#tbAlign').innerHTML = icon({ left: 'al', center: 'ac', right: 'ar', justify: 'aj' }[a] || 'al');
}

/* Blocks touched by the selection (paragraph-level formatting). */
function selectedBlocks() {
  restoreSelection();
  const doc = edDoc(), sel = getSelection(); if (!sel.rangeCount) return [];
  const r = sel.getRangeAt(0);
  let blocks = [...doc.querySelectorAll('p,h1,h2,h3,blockquote,li')].filter(b => r.intersectsNode(b));
  blocks = blocks.filter(b => !blocks.some(o => o !== b && b.contains(o)));
  if (!blocks.length) { document.execCommand('formatBlock', false, '<p>'); const b = currentBlock(); if (b) blocks = [b]; }
  return blocks;
}
function setBlockStyle(prop, value) {
  const bs = selectedBlocks();
  bs.forEach(b => { if (value == null) b.style.removeProperty(prop); else b.style.setProperty(prop, value); if (!b.getAttribute('style')) b.removeAttribute('style'); });
  afterFormat();
}

const PARA_STYLES = [
  { id: 'title', label: 'Title', tag: 'h1' },
  { id: 'author', label: 'Author', tag: 'p', cls: 'author' },
  { id: 'date', label: 'Date', tag: 'p', cls: 'dateline' },
  { id: 'h2', label: 'Heading', tag: 'h2' },
  { id: 'h3', label: 'Subheading', tag: 'h3' },
  { id: 'body', label: 'Body', tag: 'p' },
  { id: 'quote', label: 'Quotation', tag: 'blockquote' },
];
function currentParaStyle() {
  const b = currentBlock(); if (!b) return 'body';
  if (b.closest('blockquote')) return 'quote';
  if (b.tagName === 'H1') return 'title'; if (b.tagName === 'H2') return 'h2'; if (b.tagName === 'H3') return 'h3';
  if (b.classList.contains('author')) return 'author'; if (b.classList.contains('dateline')) return 'date';
  return 'body';
}
function setParaStyle(id) {
  const st = PARA_STYLES.find(s => s.id === id);
  restoreSelection();
  // leave a quotation first so styles do not nest
  if (id !== 'quote' && currentBlock()?.closest('blockquote')) document.execCommand('formatBlock', false, '<p>');
  document.execCommand('formatBlock', false, `<${st.tag}>`);
  for (const b of selectedBlocks()) {
    b.classList.remove('author', 'dateline');
    if (st.cls) b.classList.add(st.cls);
    if (!b.className) b.removeAttribute('class');
  }
  afterFormat();
}

/* Inline style on the selection, e.g. {fontSize:'14pt'}. Collapsed caret → styled insertion point. */
function applyInline(styles) {
  restoreSelection();
  const sel = getSelection(); if (!sel.rangeCount) return;
  const r = sel.getRangeAt(0);
  if (r.collapsed) {
    const span = document.createElement('span');
    Object.assign(span.style, styles);
    span.textContent = '​';
    r.insertNode(span);
    const nr = document.createRange(); nr.setStart(span.firstChild, 1); nr.collapse(true);
    sel.removeAllRanges(); sel.addRange(nr); savedRange = nr.cloneRange();
    afterFormat(); return;
  }
  const MARK = 'lp-mark-' + Math.random().toString(36).slice(2, 7);
  try { document.execCommand('styleWithCSS', false, true); } catch (e) {}
  document.execCommand('fontName', false, MARK);
  const doc = edDoc();
  let marked = [...doc.querySelectorAll('[style*="' + MARK + '"], font[face="' + MARK + '"]')];
  marked = marked.map(el => {
    if (el.tagName === 'FONT') { const s = document.createElement('span'); while (el.firstChild) s.append(el.firstChild); el.replaceWith(s); return s; }
    el.style.removeProperty('font-family'); return el;
  });
  for (const el of marked) {
    for (const [k, v] of Object.entries(styles)) {
      el.style[k] = v;
      el.querySelectorAll('[style]').forEach(c => { c.style[k] = ''; if (!c.getAttribute('style')) c.removeAttribute('style'); });
    }
  }
  if (marked.length) {
    const nr = document.createRange(); nr.setStartBefore(marked[0]); nr.setEndAfter(marked[marked.length - 1]);
    sel.removeAllRanges(); sel.addRange(nr); savedRange = nr.cloneRange();
  }
  afterFormat();
}
function currentInline(prop) {
  const sel = getSelection(), doc = edDoc(); if (!sel.rangeCount || !doc) return null;
  let n = sel.anchorNode; if (!doc.contains(n)) return null; if (n.nodeType === 3) n = n.parentNode;
  return getComputedStyle(n)[prop];
}

const SIZES = [8, 9, 10, 10.5, 11, 12, 13, 14, 16, 18, 20, 24, 28, 32, 36, 48, 60, 72];
const INKS = [['Ink', '#1D1A16'], ['Graphite', '#5F584E'], ['Oxblood', '#8A3A2B'], ['Indigo', '#2F3E5C'], ['Moss', '#4E5B3A'], ['Sepia', '#7A5A36']];
const HIGHLIGHTS = [['None', 'transparent'], ['Wheat', '#F3E3A6'], ['Sage', '#DCE6CC'], ['Rose', '#F2D6CF'], ['Sky', '#D7E3EE']];
const WEIGHTS = [['Regular', 400], ['Medium', 500], ['Semibold', 600], ['Bold', 700]];

let formatPanel = null, formatPanelRefresh = null;
function closeFormatPanel() { formatPanel?.close(); }
function toggleFormatPanel() {
  if (formatPanel) return closeFormatPanel();
  const p = panel({ title: 'Format', scrim: false, cls: 'format' + (keyboardUp() ? '' : ' nokb'), onClose: () => { formatPanel = null; formatPanelRefresh = null; $('[data-cmd="panel"]')?.setAttribute('aria-pressed', 'false'); } });
  formatPanel = p;
  $('[data-cmd="panel"]').setAttribute('aria-pressed', 'true');
  p.el.style.bottom = `calc(var(--kb) + ${$('#toolbar').offsetHeight}px)`;
  p.body.innerHTML = `
    <div class="sec"><div class="stylechips" id="fStyles">${PARA_STYLES.map(s => `<button data-style="${s.id}" class="s-${s.id}">${s.label}</button>`).join('')}</div></div>
    <div class="sec"><span class="lbl">Typeface</span>
      <div class="row2"><button class="fontrow-btn" id="fFont"><span class="nm"></span>${icon('chev')}</button>
      <div class="stepper" style="flex:0 0 150px"><button data-size="-1" aria-label="Smaller">−</button><output id="fSize"></output><button data-size="1" aria-label="Larger">+</button></div></div></div>
    <div class="sec"><span class="lbl">Weight</span><div class="seg" id="fWeight">${WEIGHTS.map(([l, w]) => `<button data-weight="${w}" style="font-weight:${w}">${l}</button>`).join('')}</div></div>
    <div class="sec"><span class="lbl">Emphasis</span><div class="seg" id="fEmph">
      ${[['bold', 'bold'], ['italic', 'italic'], ['underline', 'underline'], ['strikeThrough', 'strike'], ['superscript', 'sup'], ['subscript', 'sub']].map(([c, i]) => `<button data-exec="${c}" aria-label="${c}">${icon(i)}</button>`).join('')}</div></div>
    <div class="sec"><span class="lbl">Alignment &amp; lists</span><div class="row2">
      <div class="seg" id="fAlign">${['left', 'center', 'right', 'justify'].map(a => `<button data-align="${a}" aria-label="Align ${a}">${icon({ left: 'al', center: 'ac', right: 'ar', justify: 'aj' }[a])}</button>`).join('')}</div>
      <div class="seg" style="flex:0 0 40%"><button data-exec="insertUnorderedList" aria-label="Bulleted list">${icon('ul')}</button><button data-exec="insertOrderedList" aria-label="Numbered list">${icon('ol')}</button></div></div></div>
    <div class="sec"><span class="lbl">Indentation</span><div class="seg" id="fIndent">
      <button data-indent="-1" aria-label="Decrease indent">${icon('outdent')}</button><button data-indent="1" aria-label="Increase indent">${icon('indent')}</button>
      <button data-first="toggle" id="fFirst">First line</button></div></div>
    <div class="sec"><span class="lbl">Line spacing</span><div class="seg" id="fLH">${[1, 1.15, 1.5, 2].map(v => `<button data-lh="${v}">${v.toFixed(v === 1.15 ? 2 : 1)}</button>`).join('')}</div></div>
    <div class="sec"><span class="lbl">Space after paragraph</span><div class="seg" id="fPS">${[['None', 0], ['Small', 0.5], ['Medium', 1], ['Large', 1.6]].map(([l, v]) => `<button data-ps="${v}">${l}</button>`).join('')}</div></div>
    <div class="sec"><span class="lbl">Text colour</span><div class="swatches" id="fInk">${INKS.map(([l, c]) => `<button class="sw" data-ink="${c}" aria-label="${l}" style="background:${c}"></button>`).join('')}</div></div>
    <div class="sec"><span class="lbl">Highlight</span><div class="swatches" id="fHL">${HIGHLIGHTS.map(([l, c]) => `<button class="sw hl-sw ${c === 'transparent' ? 'none' : ''}" data-hl="${c}" aria-label="${l}" style="${c !== 'transparent' ? `background:${c}` : ''}"></button>`).join('')}</div></div>
    <div class="sec" style="margin-bottom:6px"><button class="btn small" data-exec="removeFormat">Clear text formatting</button></div>`;

  // keep the caret in the page while using the panel
  p.el.addEventListener('pointerdown', e => { if (e.target.closest('button')) e.preventDefault(); });
  p.el.addEventListener('mousedown', e => { if (e.target.closest('button')) e.preventDefault(); });
  p.body.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    const d = b.dataset;
    if (d.style) setParaStyle(d.style);
    else if (b.id === 'fFont') openFontLibrary('selection');
    else if (d.size) { const cur = parseFloat(currentInline('fontSize')) * 0.75 || 13; let i = SIZES.findIndex(s => s >= cur - 0.01); if (i < 0) i = SIZES.length - 1; if (+d.size < 0 && SIZES[i] >= cur - 0.01) i--; else if (+d.size > 0 && SIZES[i] <= cur + 0.01) i++; i = Math.max(0, Math.min(SIZES.length - 1, i)); applyInline({ fontSize: SIZES[i] + 'pt' }); }
    else if (d.weight) applyInline({ fontWeight: d.weight });
    else if (d.exec) exec(d.exec);
    else if (d.align) setAlign(d.align);
    else if (d.indent) {
      const b0 = currentBlock();
      if (b0?.tagName === 'LI') exec(+d.indent > 0 ? 'indent' : 'outdent');
      else { const bs = selectedBlocks(); bs.forEach(x => { const m = Math.max(0, (parseFloat(x.style.marginLeft) || 0) + (+d.indent) * 2); if (m) x.style.marginLeft = m + 'em'; else x.style.removeProperty('margin-left'); if (!x.getAttribute('style')) x.removeAttribute('style'); }); afterFormat(); }
    }
    else if (d.first) { const b0 = currentBlock(); const on = b0 && parseFloat(getComputedStyle(b0).textIndent) > 0; setBlockStyle('text-indent', on ? '0' : '1.5em'); }
    else if (d.lh) setBlockStyle('line-height', d.lh);
    else if (d.ps) setBlockStyle('margin-bottom', d.ps + 'em');
    else if (d.ink) exec('foreColor', d.ink);
    else if (d.hl) exec('hiliteColor', d.hl);
  });
  formatPanelRefresh = () => refreshFormatPanel(p);
  refreshFormatPanel(p);
}
function refreshFormatPanel(p) {
  if (!p || p.closed) return;
  const ps = currentParaStyle();
  $$('#fStyles button', p.el).forEach(b => b.setAttribute('aria-pressed', b.dataset.style === ps));
  const fam = (currentInline('fontFamily') || '').split(',')[0].replace(/["']/g, '').trim();
  const f = fonts.REGISTRY.find(x => x.name === fam || x.stack.split(',')[0].replace(/"/g, '').trim() === fam);
  const nm = $('#fFont .nm', p.el); nm.textContent = f ? fontLabel(f.id) : fam || 'Document font'; nm.style.fontFamily = f ? f.stack : '';
  const px = parseFloat(currentInline('fontSize')); $('#fSize', p.el).textContent = px ? `${+(px * 0.75).toFixed(1)} pt` : '–';
  const w = +currentInline('fontWeight') || 400;
  $$('#fWeight button', p.el).forEach(b => b.setAttribute('aria-pressed', Math.abs(+b.dataset.weight - w) < 50));
  for (const c of ['bold', 'italic', 'underline', 'strikeThrough', 'superscript', 'subscript', 'insertUnorderedList', 'insertOrderedList']) {
    let on = false; try { on = document.queryCommandState(c); } catch (e) {}
    $$(`[data-exec="${c}"]`, p.el).forEach(b => b.setAttribute('aria-pressed', on));
  }
  const a = currentAlign(); $$('#fAlign button', p.el).forEach(b => b.setAttribute('aria-pressed', b.dataset.align === a));
  const blk = currentBlock();
  if (blk) {
    const cs = getComputedStyle(blk), fs = parseFloat(cs.fontSize);
    $('#fFirst', p.el).setAttribute('aria-pressed', parseFloat(cs.textIndent) > 0);
    const lh = cs.lineHeight === 'normal' ? 1.2 : parseFloat(cs.lineHeight) / fs;
    $$('#fLH button', p.el).forEach(b => b.setAttribute('aria-pressed', Math.abs(+b.dataset.lh - lh) < 0.04));
    const mb = parseFloat(cs.marginBottom) / fs;
    $$('#fPS button', p.el).forEach(b => b.setAttribute('aria-pressed', Math.abs(+b.dataset.ps - mb) < 0.08));
  }
  const ink = rgbToHex(currentInline('color')); $$('#fInk .sw', p.el).forEach(b => b.setAttribute('aria-pressed', b.dataset.ink.toLowerCase() === ink));
}
function rgbToHex(c) { const m = (c || '').match(/\d+/g); return m ? '#' + m.slice(0, 3).map(x => (+x).toString(16).padStart(2, '0')).join('') : ''; }

/* ========================================================================
   FONT LIBRARY  (mode: 'selection' | 'document' | 'default' | 'browse')
   ======================================================================== */
function openFontLibrary(mode = 'browse') {
  const keepRange = savedRange;
  const current = mode === 'document' ? state.current?.settings.font : mode === 'default' ? store.pref('defaultFont', fonts.DEFAULT_FONT) : null;
  const title = mode === 'selection' ? 'Font for Selection' : mode === 'document' ? 'Document Font' : mode === 'default' ? 'Default Font' : 'Typefaces';
  const p = panel({ title, full: true });
  let filter = 'all', q = '';
  p.body.innerHTML = `
    <label class="fontsearch">${icon('search')}<input type="text" inputmode="search" placeholder="Search typefaces" autocomplete="off" spellcheck="false"></label>
    <div class="fontfilters">${[['all', 'All'], ['serif', 'Serif'], ['sans', 'Sans'], ['bundled', 'Built in'], ['added', 'Added']].map(([k, l]) => `<button data-f="${k}" aria-pressed="${k === 'all'}">${l}</button>`).join('')}</div>
    <ul class="fontlist" id="fontList"></ul>
    <div class="sec prose"><h4>Add a typeface</h4>
      <p>Add a .ttf, .otf, .woff or .woff2 file from the Files app. It stays on this device and works offline. This is also how a typeface you design yourself comes in.</p>
      <button class="btn small" id="addFont">${icon('plus')}<span>Add Font File…</span></button></div>`;
  const PV = 'Quiet light on the open page';
  const PV2 = '& the long revision of the night, 1,024';
  const draw = () => {
    const items = fonts.REGISTRY.filter(f => {
      if (q && !f.name.toLowerCase().includes(q)) return false;
      if (filter === 'serif' || filter === 'sans') return f.cat === filter;
      if (filter === 'bundled') return f.kind === 'bundled';
      if (filter === 'added') return f.kind === 'imported' || (f.kind === 'importable' && fonts.isAvailable(f.id));
      return true;
    });
    // Garamond first, then available, then the rest
    items.sort((a, b) => (b.id === 'eb-garamond') - (a.id === 'eb-garamond') || fonts.isAvailable(b.id) - fonts.isAvailable(a.id));
    $('#fontList', p.el).innerHTML = items.map(f => {
      const ok = fonts.isAvailable(f.id);
      const tag = f.kind === 'bundled' ? 'Built in' : f.kind === 'system' ? 'iPhone' : f.kind === 'imported' ? 'Added' : ok ? 'Added' : 'Not added';
      return `<li class="fontitem ${ok ? '' : 'missing'}"><button data-font="${f.id}">
        <div class="fn"><b>${esc(f.name)}</b><span class="tag">${tag}</span>${f.id === fonts.DEFAULT_FONT ? '<span class="tag">Default</span>' : ''}${current === f.id ? `<span class="chk">${icon('check')}</span>` : ''}</div>
        <div class="pv" style="font-family:${esc(ok ? f.stack : 'inherit')}">${ok ? PV : esc(f.name)}</div>
        ${ok ? `<div class="pv2" style="font-family:${esc(f.stack)}">${PV2}</div>` : ''}
        ${!ok || f.note ? `<div class="note">${esc(!ok ? (f.kind === 'system' ? 'Not available on this device.' : f.note + ' Tap to add the file.') : f.note)}</div>` : ''}
      </button></li>`;
    }).join('');
  };
  draw();
  $('input', p.el).addEventListener('input', e => { q = e.target.value.trim().toLowerCase(); draw(); });
  $('.fontfilters', p.el).addEventListener('click', e => { const b = e.target.closest('[data-f]'); if (!b) return; filter = b.dataset.f; $$('.fontfilters button', p.el).forEach(x => x.setAttribute('aria-pressed', x === b)); draw(); });
  $('#addFont', p.el).onclick = () => importFont(null, () => { draw(); applyUIFont(); });
  $('#fontList', p.el).addEventListener('click', e => {
    const b = e.target.closest('[data-font]'); if (!b) return;
    const f = fonts.byId(b.dataset.font);
    if (!fonts.isAvailable(f.id)) {
      if (f.kind === 'system') return info(f.name, 'This typeface isn’t on this device. It is on iPhone, so it will appear when you use Lamplight there.');
      return importFont(f.name, () => { draw(); applyUIFont(); });
    }
    if (mode === 'selection') { p.close(); savedRange = keepRange; applyInline({ fontFamily: f.stack }); }
    else if (mode === 'document') { p.close(); setDocSetting('font', f.id); toast(`Document font: ${f.name}`); }
    else if (mode === 'default') { store.setPref('defaultFont', f.id); p.close(); toast(`New documents will use ${f.name}`); }
    else info(f.name, f.note || 'Choose it from the Format panel or Document Settings.');
  });
}

function importFont(expectedFamily, done) {
  const inp = $('#fontFile');
  inp.value = '';
  inp.onchange = async () => {
    const file = inp.files[0]; if (!file) return;
    const guess = fonts.guessFromFilename(file.name);
    const fam = expectedFamily || await ask('Typeface name', guess.family, 'Add', 'Each style (italic, bold) is its own file; add them under the same name.');
    if (fam === null) return;
    try {
      const r = await fonts.importFile(file, fam || guess.family);
      toast(`Added ${r.entry.name} ${r.style === 'italic' ? 'Italic' : ''} (${r.weight})`.replace(/\s+/g, ' '));
      if (r.entry.id === 'eb-garamond' && r.style === 'normal') toast('EB Garamond added. Add the Italic file too for true italics.');
      done && done();
    } catch (e) { console.error(e); info('That file couldn’t be used', 'Lamplight accepts TrueType (.ttf), OpenType (.otf) and WOFF files.'); }
  };
  inp.click();
}

/* ========================================================================
   DOCUMENT SETTINGS
   ======================================================================== */
function setDocSetting(key, value) {
  const d = state.current; if (!d) return;
  d.settings[key] = value; saveMeta(d);
  if (['mode', 'pageSize', 'margins', 'zoom'].includes(key)) layoutCanvas();
  else { applyDocVars(); edDoc().classList.toggle('indent-first', !!d.settings.firstIndent); if (d.settings.mode === 'paged') paginate(); }
  updateCounts();
}
function openDocSettings() {
  const d = state.current; if (!d) return;
  const s = d.settings;
  const p = panel({ title: 'Document Settings', full: NARROW() });
  const seg = (key, opts, cls = '') => `<div class="seg ${cls}" data-key="${key}">${opts.map(([v, l]) => `<button data-v="${esc(String(v))}" aria-pressed="${String(s[key]) === String(v)}">${l}</button>`).join('')}</div>`;
  const draw = () => {
    p.body.innerHTML = `
    <div class="sec"><label>View</label>${seg('mode', [['paged', 'Paged'], ['continuous', 'Continuous']])}</div>
    <div class="sec" ${s.mode !== 'paged' ? 'hidden' : ''}><label>Zoom</label>${seg('zoom', [['fit', 'Fit'], ['0.75', '75%'], ['1', '100%'], ['1.25', '125%']])}</div>
    <div class="sec"><label>Page size</label>${seg('pageSize', Object.entries(PAGE_SIZES).map(([k, v]) => [k, v.label]))}</div>
    <div class="sec"><label>Margins</label>${seg('marginPreset', [['narrow', 'Narrow'], ['normal', 'Normal'], ['wide', 'Wide'], ['custom', 'Custom']])}
      <div class="marginbox" ${s.marginPreset !== 'custom' ? 'hidden' : ''} style="margin-top:6px">
        ${[['t', 'Top'], ['b', 'Bottom'], ['l', 'Left'], ['r', 'Right']].map(([k, l]) => `<div class="field"><span>${l}</span><input type="number" step="0.05" min="0.25" max="2.5" inputmode="decimal" data-m="${k}" value="${s.margins[k]}"><span style="flex:0;color:var(--ink-3)">in</span></div>`).join('')}</div></div>
    <div class="sec"><label>Header &amp; footer</label>
      <div class="field"><span>Header</span><input type="text" data-t="header" value="${esc(s.header)}" placeholder="e.g. Surname / Title" style="flex:2"></div>
      <div class="field"><span>Footer</span><input type="text" data-t="footer" value="${esc(s.footer)}" placeholder="Optional" style="flex:2"></div>
      <div class="field"><span>Page numbers</span><select data-sel="pageNumbers">${[['none', 'None'], ['footer-center', 'Footer, centred'], ['footer-right', 'Footer, right'], ['header-right', 'Header, right']].map(([v, l]) => `<option value="${v}" ${s.pageNumbers === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
      <div class="field"><span>No header or number on first page</span><button class="toggle" role="switch" data-tog="firstPageDifferent" aria-checked="${!!s.firstPageDifferent}"></button></div>
      <p class="prose" style="font-size:12.5px;margin-top:8px">Headers, footers and page numbers appear in Paged view.</p></div>
    <div class="sec"><label>Text</label>
      <div class="field"><span>Font</span><button class="fontrow-btn" data-act="font" style="flex:2"><span class="nm" style="font-family:${esc(fonts.stackFor(s.font))}">${esc(fontLabel(s.font))}</span>${icon('chev')}</button></div>
      <div class="field"><span>Size</span><div class="stepper" style="flex:0 0 150px"><button data-sz="-0.5">−</button><output>${s.size} pt</output><button data-sz="0.5">+</button></div></div>
      <div style="margin-top:12px"><span class="lbl" style="font-size:11px;letter-spacing:.11em;text-transform:uppercase;color:var(--ink-3)">Line spacing</span>${seg('lineHeight', [[1, '1.0'], [1.15, '1.15'], [1.5, '1.5'], [2, '2.0']])}</div>
      <div style="margin-top:12px"><span class="lbl" style="font-size:11px;letter-spacing:.11em;text-transform:uppercase;color:var(--ink-3)">Space after paragraphs</span>${seg('paraSpacing', [[0, 'None'], [0.5, 'Small'], [1, 'Medium'], [1.6, 'Large']])}</div>
      <div class="field" style="margin-top:6px"><span>Indent first line of paragraphs</span><button class="toggle" role="switch" data-tog="firstIndent" aria-checked="${!!s.firstIndent}"></button></div>
    </div>`;
  };
  draw();
  p.body.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    const sg = b.closest('.seg[data-key]');
    if (sg) {
      const key = sg.dataset.key, v = b.dataset.v;
      if (key === 'marginPreset') {
        s.marginPreset = v;
        if (v !== 'custom') { const m = MARGIN_PRESETS[v]; setDocSetting('margins', { t: m, b: m, l: m, r: m }); } else saveMeta(d);
      } else setDocSetting(key, ['lineHeight', 'paraSpacing'].includes(key) ? +v : v);
      draw(); return;
    }
    if (b.dataset.tog) { setDocSetting(b.dataset.tog, !s[b.dataset.tog]); draw(); return; }
    if (b.dataset.sz) { setDocSetting('size', Math.max(8, Math.min(28, s.size + +b.dataset.sz))); draw(); return; }
    if (b.dataset.act === 'font') { p.close(); openFontLibrary('document'); }
  });
  p.body.addEventListener('change', e => {
    const t = e.target;
    if (t.dataset.m) { const v = Math.max(0.25, Math.min(2.5, parseFloat(t.value) || 1)); setDocSetting('margins', { ...s.margins, [t.dataset.m]: v }); }
    if (t.dataset.sel) setDocSetting(t.dataset.sel, t.value);
  });
  p.body.addEventListener('input', e => { const t = e.target; if (t.dataset.t) { s[t.dataset.t] = t.value; saveMeta(d); if (s.mode === 'paged') schedulePaginate(); } });
}

/* ========================================================================
   STATISTICS
   ======================================================================== */
function openStats() {
  const doc = edDoc(); if (!doc) return;
  const st = T.stats(doc), sel = selectionWords();
  const pages = state.current.settings.mode === 'paged' ? state.pageCount : null;
  const mins = st.words / 238;
  const read = st.words === 0 ? '—' : mins < 1 ? 'Under a minute' : mins < 60 ? `${Math.round(mins)} min` : `${Math.floor(mins / 60)} h ${Math.round(mins % 60)} min`;
  const rows = [
    ['Words', num(st.words), true],
    sel ? ['Selected words', num(sel)] : null,
    ['Characters', num(st.chars)],
    ['Characters, no spaces', num(st.charsNoSpace)],
    ['Paragraphs & lines', num(st.paragraphs)],
    st.sentencesReliable ? ['Sentences', num(st.sentences)] : null,
    ['Pages', pages ? num(pages) : `≈ ${Math.max(1, Math.ceil(st.words / 300))}`],
    ['Reading time', read],
  ].filter(Boolean);
  panel({ title: 'Statistics', body: `<div class="stats">${rows.map(([l, v, big]) => `<div>${l}</div><div class="${big ? 'big' : ''}">${v}</div>`).join('')}</div>
    <p class="prose" style="font-size:12.5px;margin-top:12px">${pages ? 'Page count follows the current page size and margins.' : 'Page count is an estimate; switch to Paged view for the exact count.'} Each line of a poem counts as its own paragraph.</p>` });
}

/* ========================================================================
   APP SETTINGS · PROFILE · PRIVACY · INSTALL
   ======================================================================== */
async function openSettings(focus) {
  const p = panel({ title: 'Settings', full: true });
  const ps = await store.persistenceStatus();
  const mb = b => b == null ? '—' : b < 1e6 ? `${Math.round(b / 1e3)} KB` : `${(b / 1e6).toFixed(1)} MB`;
  const name = store.pref('name', '');
  const dm = store.pref('defaultMode', NARROW() ? 'continuous' : 'paged');
  p.body.innerHTML = `
  <section id="s-profile"><div class="profile"><button class="avatar" id="pfPic" aria-label="Change profile picture">${store.pref('avatar') ? `<img alt="" src="${store.pref('avatar')}">` : esc((name[0] || 'L').toUpperCase())}</button>
    <div style="flex:1"><input id="pfName" value="${esc(name)}" placeholder="Your name" autocomplete="name"><div style="font-size:12px;color:var(--ink-3);margin-top:6px">Picture and name stay on this device. <button id="pfRemove" style="color:var(--accent)" ${store.pref('avatar') ? '' : 'hidden'}>Remove picture</button></div></div></div></section>
  <div class="sec"><label>New documents</label>
    <div class="field"><span>Open in</span><div class="seg" style="flex:0 0 200px" id="setMode"><button data-v="paged" aria-pressed="${dm === 'paged'}">Paged</button><button data-v="continuous" aria-pressed="${dm === 'continuous'}">Continuous</button></div></div>
    <div class="field"><span>Default font</span><button class="fontrow-btn" id="setFont" style="flex:0 0 200px"><span class="nm" style="font-family:${esc(fonts.stackFor(store.pref('defaultFont', fonts.DEFAULT_FONT)))}">${esc(fontLabel(store.pref('defaultFont', fonts.DEFAULT_FONT)))}</span>${icon('chev')}</button></div>
    <div class="field"><span>Typefaces</span><button class="btn small" id="setTypes">Font Library</button></div>
  </div>
  <div class="sec"><label>Storage on this device</label>
    <div class="field"><span>Where your writing lives</span><span style="flex:0;white-space:nowrap;color:var(--ink-2)">${store.storageMode() === 'idb' ? 'This device only' : 'Memory only ⚠︎'}</span></div>
    <div class="field"><span>Protected from automatic clearing</span><span style="flex:0;white-space:nowrap;color:var(--ink-2)">${ps.persisted == null ? 'Unknown' : ps.persisted ? 'Yes' : 'Not granted'}</span></div>
    <div class="field"><span>Space used</span><span style="flex:0;white-space:nowrap;color:var(--ink-2)">${mb(ps.usage)}</span></div>
    <div class="field"><span>Documents</span><span style="flex:0;white-space:nowrap;color:var(--ink-2)">${num(live().length)} · ${num(trashed().length)} in Trash</span></div>
  </div>
  <div class="sec prose" id="s-privacy"><h4>Privacy</h4>
    <p>Lamplight makes no network requests while you write, save, search or format. There is no analytics, tracking, advertising, AI processing or cloud sync. Fonts are bundled with the app.</p>
    <p>Honest limits: your writing is stored in this browser's storage on your iPhone. It is not encrypted yet (that comes in Stage 5), so anyone who can unlock your phone could reach it. Lamplight cannot protect against software on the device itself.</p></div>
  <div class="sec prose" id="s-install"><h4>Installing your own copy</h4>
    <p><b>Why:</b> a preview inside Claude runs in a sandbox. It can't work offline and its storage may be cleared. Your own copy, added to the Home Screen, works offline and iOS keeps its storage.</p>
    <p><b>1.</b> On github.com in Safari, create a free account and a new public repository named <i>lamplight</i>.<br>
    <b>2.</b> Unzip the Lamplight folder in the Files app. In the repository, choose <i>Add file → Upload files</i> and select everything inside the folder (keep the css, js, fonts and icons folders).<br>
    <b>3.</b> Optional: to make EB Garamond the default, download it free from fonts.google.com, then upload the two variable .ttf files into the <i>fonts</i> folder.<br>
    <b>4.</b> In the repository, open <i>Settings → Pages</i>, choose the <i>main</i> branch and save. After a minute your app is at <i>yourname.github.io/lamplight</i>.<br>
    <b>5.</b> Open that address in Safari, tap <i>Share → Add to Home Screen</i>, and always open Lamplight from that icon.</p>
    <p>GitHub only serves the app's code. Your documents never go there.</p>
    <h4>iOS limitations</h4>
    <p>• Safari can clear website storage that hasn't been used for seven days. Home Screen apps are exempt, so use the icon.<br>
    • Deleting the Home Screen app deletes its documents.<br>
    • Whether iPhone/iCloud backups include web-app data is not something Apple documents clearly, so don't rely on it. Lamplight's own backup and export (Stages 4–5) will let you keep copies wherever you choose.<br>
    • Web apps can't run in the background. Lamplight saves as you type and saves again the moment you switch away.<br>
    • Face ID isn't available to web apps. Stage 5 will use a passcode with real encryption.</p></div>
  <div class="sec prose"><h4>About</h4><p>Lamplight ${VERSION}. Typefaces: EB Garamond (when added), Crimson Pro, Lora, Libre Baskerville, IBM Plex Serif, Instrument Serif, Inter (SIL Open Font License) and TeX Gyre Pagella (GUST Font License). See fonts/LICENSES.txt.</p></div>`;

  $('#pfPic', p.el).onclick = () => pickAvatar(() => { p.close(); openSettings('profile'); });
  $('#pfRemove', p.el).onclick = async () => { await store.setPref('avatar', null); renderAvatar(); p.close(); openSettings('profile'); };
  $('#pfName', p.el).addEventListener('change', e => { store.setPref('name', e.target.value.trim()); renderAvatar(); });
  $('#setMode', p.el).onclick = e => { const b = e.target.closest('[data-v]'); if (!b) return; store.setPref('defaultMode', b.dataset.v); $$('#setMode button', p.el).forEach(x => x.setAttribute('aria-pressed', x === b)); };
  $('#setFont', p.el).onclick = () => { p.close(); openFontLibrary('default'); };
  $('#setTypes', p.el).onclick = () => { p.close(); openFontLibrary('browse'); };
  if (focus) setTimeout(() => $('#s-' + focus, p.el)?.scrollIntoView({ block: 'start' }), 260);
}

function pickAvatar(done) {
  const inp = $('#avatarFile'); inp.value = '';
  inp.onchange = () => {
    const f = inp.files[0]; if (!f) return;
    const img = new Image(), url = URL.createObjectURL(f);
    img.onload = async () => {
      const S = 256, c = document.createElement('canvas'); c.width = c.height = S;
      const k = Math.max(S / img.width, S / img.height), w = img.width * k, h = img.height * k;
      c.getContext('2d').drawImage(img, (S - w) / 2, (S - h) / 2, w, h);
      URL.revokeObjectURL(url);
      await store.setPref('avatar', c.toDataURL('image/jpeg', 0.86));
      renderAvatar(); done && done();
    };
    img.onerror = () => info('That image couldn’t be read', 'Try a JPEG or PNG.');
    img.src = url;
  };
  inp.click();
}

/* ========================================================================
   KEYBOARD / TOOLBAR POSITIONING
   ======================================================================== */
let kbH = 0;
const keyboardUp = () => kbH > 80;
function watchKeyboard() {
  const vv = window.visualViewport; if (!vv) return;
  const upd = () => {
    kbH = Math.max(0, innerHeight - vv.height - vv.offsetTop);
    document.documentElement.style.setProperty('--kb', kbH + 'px');
    $('#toolbar')?.classList.toggle('nokb', !keyboardUp());
    const fp = $('.panel.format'); fp && fp.classList.toggle('nokb', !keyboardUp());
  };
  vv.addEventListener('resize', upd); vv.addEventListener('scroll', upd); upd();
}
function showToolbar(on) {
  const tb = $('#toolbar'); if (!tb) return;
  tb.hidden = !on;
  if (on) { tb.classList.toggle('nokb', !keyboardUp()); updateToolbarState(); }
  else closeFormatPanel();
  $('#canvas').style.paddingBottom = on ? '56px' : '';
}

/* ========================================================================
   CARET HELPERS
   ======================================================================== */
function caretOffset(root) {
  const sel = getSelection(); if (!sel.rangeCount || !root.contains(sel.anchorNode)) return null;
  const r = sel.getRangeAt(0).cloneRange(); r.selectNodeContents(root); r.setEnd(sel.anchorNode, sel.anchorOffset);
  return r.toString().length;
}
function placeCaretAtOffset(root, off, noFocus) {
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let n, left = off;
  while ((n = w.nextNode())) { if (left <= n.nodeValue.length) break; left -= n.nodeValue.length; }
  const r = document.createRange();
  if (n) r.setStart(n, Math.max(0, left)); else { r.selectNodeContents(root.firstElementChild || root); r.collapse(off === 0); if (off !== 0) r.collapse(false); }
  r.collapse(true);
  const sel = getSelection(); sel.removeAllRanges(); sel.addRange(r); savedRange = r.cloneRange();
}
function placeCaretEnd(el) { const r = document.createRange(); r.selectNodeContents(el); r.collapse(false); const s = getSelection(); s.removeAllRanges(); s.addRange(r); }

boot();
