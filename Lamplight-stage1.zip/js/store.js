/* ==========================================================================
   Lamplight — local storage layer
   - IndexedDB is the library (metadata, bodies, folders, prefs, fonts).
   - A synchronous recovery copy of the document being edited is written to
     localStorage on every change, so a crash or forced close between
     IndexedDB commits loses nothing. It is cleared once the commit lands.
   - If IndexedDB is unavailable (some sandboxed previews), everything falls
     back to memory and the UI says so plainly: nothing is pretended.
   Nothing here touches the network.
   ========================================================================== */

const DB_NAME = 'lamplight';
const DB_VERSION = 1;
const STORES = ['docs', 'bodies', 'folders', 'prefs', 'fonts'];
const RECOVER_PREFIX = 'lp.recover.';

let db = null;
let mode = 'idb';                 // 'idb' | 'memory'
const mem = Object.fromEntries(STORES.map(s => [s, new Map()]));

function req(r) {
  return new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
}

export async function open() {
  try {
    if (!('indexedDB' in window)) throw new Error('no indexedDB');
    db = await new Promise((res, rej) => {
      const r = indexedDB.open(DB_NAME, DB_VERSION);
      r.onupgradeneeded = () => {
        const d = r.result;
        if (!d.objectStoreNames.contains('docs')) d.createObjectStore('docs', { keyPath: 'id' });
        if (!d.objectStoreNames.contains('bodies')) d.createObjectStore('bodies', { keyPath: 'id' });
        if (!d.objectStoreNames.contains('folders')) d.createObjectStore('folders', { keyPath: 'id' });
        if (!d.objectStoreNames.contains('prefs')) d.createObjectStore('prefs', { keyPath: 'key' });
        if (!d.objectStoreNames.contains('fonts')) d.createObjectStore('fonts', { keyPath: 'id' });
      };
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
      r.onblocked = () => rej(new Error('blocked'));
      setTimeout(() => rej(new Error('timeout')), 4000);
    });
    db.onversionchange = () => db.close();
    mode = 'idb';
  } catch (e) {
    console.warn('[Lamplight] IndexedDB unavailable, using memory:', e);
    mode = 'memory';
  }
  return mode;
}

export const storageMode = () => mode;

/* Ask the browser to treat our storage as persistent (not evictable under pressure). */
export async function requestPersistence() {
  try {
    if (navigator.storage && navigator.storage.persist) {
      if (await navigator.storage.persisted()) return true;
      return await navigator.storage.persist();
    }
  } catch (e) {}
  return false;
}
export async function persistenceStatus() {
  const out = { persisted: null, usage: null, quota: null };
  try {
    if (navigator.storage?.persisted) out.persisted = await navigator.storage.persisted();
    if (navigator.storage?.estimate) { const e = await navigator.storage.estimate(); out.usage = e.usage; out.quota = e.quota; }
  } catch (e) {}
  return out;
}

/* ---------- generic CRUD ---------- */
export async function all(store) {
  if (mode === 'memory') return [...mem[store].values()].map(clone);
  const tx = db.transaction(store, 'readonly');
  return req(tx.objectStore(store).getAll());
}
export async function get(store, key) {
  if (mode === 'memory') { const v = mem[store].get(key); return v ? clone(v) : undefined; }
  const tx = db.transaction(store, 'readonly');
  return req(tx.objectStore(store).get(key));
}
/* put several records across stores in ONE transaction (atomic). */
export async function putMany(entries /* [[store, value], ...] */) {
  if (mode === 'memory') { for (const [s, v] of entries) mem[s].set(v.id ?? v.key, clone(v)); return; }
  const names = [...new Set(entries.map(e => e[0]))];
  const tx = db.transaction(names, 'readwrite');
  for (const [s, v] of entries) tx.objectStore(s).put(v);
  await new Promise((res, rej) => { tx.oncomplete = res; tx.onerror = () => rej(tx.error); tx.onabort = () => rej(tx.error || new Error('abort')); });
}
export const put = (store, value) => putMany([[store, value]]);
export async function delMany(entries /* [[store, key], ...] */) {
  if (mode === 'memory') { for (const [s, k] of entries) mem[s].delete(k); return; }
  const names = [...new Set(entries.map(e => e[0]))];
  const tx = db.transaction(names, 'readwrite');
  for (const [s, k] of entries) tx.objectStore(s).delete(k);
  await new Promise((res, rej) => { tx.oncomplete = res; tx.onerror = () => rej(tx.error); });
}

/* ---------- prefs ---------- */
const prefCache = new Map();
export async function loadPrefs() {
  for (const p of await all('prefs')) prefCache.set(p.key, p.value);
}
export const pref = (k, d) => prefCache.has(k) ? prefCache.get(k) : d;
export async function setPref(k, v) {
  prefCache.set(k, v);
  try { await put('prefs', { key: k, value: v }); } catch (e) { console.warn(e); }
}

/* ---------- crash recovery copy (synchronous) ---------- */
export function writeRecovery(id, html) {
  try { localStorage.setItem(RECOVER_PREFIX + id, JSON.stringify({ t: Date.now(), html })); return true; }
  catch (e) { return false; }
}
export function clearRecovery(id) { try { localStorage.removeItem(RECOVER_PREFIX + id); } catch (e) {} }
export function listRecovery() {
  const out = [];
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(RECOVER_PREFIX)) {
        try { out.push({ id: k.slice(RECOVER_PREFIX.length), ...JSON.parse(localStorage.getItem(k)) }); } catch (e) {}
      }
    }
  } catch (e) {}
  return out;
}

function clone(v) { return v == null ? v : (typeof structuredClone === 'function' ? structuredClone(v) : JSON.parse(JSON.stringify(v))); }

export const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2));
