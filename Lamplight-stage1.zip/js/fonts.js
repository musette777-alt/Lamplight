/* ==========================================================================
   Lamplight — typography registry
   Three sources, one list:
     bundled  : shipped in /fonts, always available offline
     system   : provided by iOS (detected, never downloaded)
     imported : font files the writer adds from the Files app (stored in
                IndexedDB, registered with the FontFace API). This is also the
                path for a typeface the writer designs later.
   Adding a typeface later = one entry here (+ files), or an in-app import.
   ========================================================================== */
import * as store from './store.js';

const FALL_SERIF = 'Georgia, "Times New Roman", serif';
const FALL_SANS = '-apple-system, system-ui, Helvetica, Arial, sans-serif';

export const REGISTRY = [
  { id: 'eb-garamond', name: 'EB Garamond', kind: 'importable', cat: 'serif', stack: `"EB Garamond", "Crimson Pro", ${FALL_SERIF}`,
    note: 'The typeface Lolwe uses. Free (SIL OFL). Add its file once and it becomes available offline.', lolwe: true },
  { id: 'crimson-pro', name: 'Crimson Pro', kind: 'bundled', cat: 'serif', stack: `"Crimson Pro", ${FALL_SERIF}`, note: 'Garamond-model book face; the closest bundled match to EB Garamond.' },
  { id: 'lora', name: 'Lora', kind: 'bundled', cat: 'serif', stack: `"Lora", ${FALL_SERIF}`, note: 'Variable weight 400–700.' },
  { id: 'libre-baskerville', name: 'Libre Baskerville', kind: 'bundled', cat: 'serif', stack: `"Libre Baskerville", ${FALL_SERIF}`, note: 'Regular only; italic and bold are synthesised.' },
  { id: 'ibm-plex-serif', name: 'IBM Plex Serif', kind: 'bundled', cat: 'serif', stack: `"IBM Plex Serif", ${FALL_SERIF}` },
  { id: 'instrument-serif', name: 'Instrument Serif', kind: 'bundled', cat: 'serif', stack: `"Instrument Serif", ${FALL_SERIF}`, note: 'Display face for titles.' },
  { id: 'pagella', name: 'TeX Gyre Pagella', kind: 'bundled', cat: 'serif', stack: `"TeX Gyre Pagella", Palatino, ${FALL_SERIF}`, note: 'Palatino design, freely licensed.' },
  { id: 'inter', name: 'Inter', kind: 'bundled', cat: 'sans', stack: `"Inter", ${FALL_SANS}` },
  { id: 'literata', name: 'Literata', kind: 'importable', cat: 'serif', stack: `"Literata", ${FALL_SERIF}`, note: 'Free (SIL OFL). Add its file to use it.' },
  { id: 'cormorant-garamond', name: 'Cormorant Garamond', kind: 'importable', cat: 'serif', stack: `"Cormorant Garamond", ${FALL_SERIF}`, note: 'Free (SIL OFL). Add its file to use it.' },
  { id: 'georgia', name: 'Georgia', kind: 'system', cat: 'serif', stack: `Georgia, serif`, probe: 'Georgia' },
  { id: 'palatino', name: 'Palatino', kind: 'system', cat: 'serif', stack: `Palatino, "Palatino Linotype", "TeX Gyre Pagella", serif`, probe: 'Palatino' },
  { id: 'baskerville', name: 'Baskerville', kind: 'system', cat: 'serif', stack: `Baskerville, "Libre Baskerville", serif`, probe: 'Baskerville' },
  { id: 'times', name: 'Times New Roman', kind: 'system', cat: 'serif', stack: `"Times New Roman", Times, serif`, probe: 'Times New Roman' },
  { id: 'hoefler', name: 'Hoefler Text', kind: 'system', cat: 'serif', stack: `"Hoefler Text", ${FALL_SERIF}`, probe: 'Hoefler Text' },
  { id: 'iowan', name: 'Iowan Old Style', kind: 'system', cat: 'serif', stack: `"Iowan Old Style", ${FALL_SERIF}`, probe: 'Iowan Old Style' },
  { id: 'charter', name: 'Charter', kind: 'system', cat: 'serif', stack: `Charter, ${FALL_SERIF}`, probe: 'Charter' },
  { id: 'didot', name: 'Didot', kind: 'system', cat: 'serif', stack: `Didot, ${FALL_SERIF}`, probe: 'Didot' },
  { id: 'cochin', name: 'Cochin', kind: 'system', cat: 'serif', stack: `Cochin, ${FALL_SERIF}`, probe: 'Cochin' },
  { id: 'helvetica', name: 'Helvetica', kind: 'system', cat: 'sans', stack: `"Helvetica Neue", Helvetica, Arial, sans-serif`, probe: 'Helvetica' },
  { id: 'arial', name: 'Arial', kind: 'system', cat: 'sans', stack: `Arial, Helvetica, sans-serif`, probe: 'Arial' },
  { id: 'avenir', name: 'Avenir Next', kind: 'system', cat: 'sans', stack: `"Avenir Next", Avenir, ${FALL_SANS}`, probe: 'Avenir Next' },
  { id: 'gill-sans', name: 'Gill Sans', kind: 'system', cat: 'sans', stack: `"Gill Sans", ${FALL_SANS}`, probe: 'Gill Sans' },
];

const avail = new Map();      // id -> boolean
let imported = [];            // [{id, family, ...}] faces from IndexedDB

export const DEFAULT_FONT = 'eb-garamond';

export function byId(id) { return REGISTRY.find(f => f.id === id) || REGISTRY.find(f => f.id === 'crimson-pro'); }
export function stackFor(id) { return byId(id).stack; }
export const isAvailable = id => avail.get(id) === true;
export const list = () => REGISTRY;

/* Is a *system* family present? Compare glyph widths against generic fallbacks. */
function systemHas(family) {
  try {
    const c = document.createElement('canvas').getContext('2d');
    const s = 'mmmmmmmmmlliWWQ@&1234567890 abcdefghij';
    const w = f => { c.font = `48px ${f}`; return c.measureText(s).width; };
    const a = w('monospace'), b = w('serif'), d = w('sans-serif');
    return w(`"${family}", monospace`) !== a || w(`"${family}", serif`) !== b || w(`"${family}", sans-serif`) !== d;
  } catch (e) { return false; }
}

async function faceLoaded(family) {
  try { await document.fonts.load(`16px "${family}"`); await document.fonts.load(`italic 16px "${family}"`); } catch (e) {}
  for (const f of document.fonts) if (f.family.replace(/"/g, '') === family && f.status === 'loaded') return true;
  return false;
}

export async function init() {
  // Register fonts the writer imported earlier.
  try { imported = await store.all('fonts'); } catch (e) { imported = []; }
  for (const f of imported) {
    try {
      const face = new FontFace(f.family, f.data, { style: f.style, weight: f.weight });
      await face.load(); document.fonts.add(face);
      if (!REGISTRY.some(r => r.name.toLowerCase() === f.family.toLowerCase())) {
        REGISTRY.push({ id: 'u-' + slug(f.family), name: f.family, kind: 'imported', cat: 'serif', stack: `"${f.family}", ${FALL_SERIF}`, note: 'Added from your files.' });
      }
    } catch (e) { console.warn('font failed', f.family, e); }
  }
  for (const r of REGISTRY) {
    if (r.kind === 'bundled') avail.set(r.id, true);
    else if (r.kind === 'system') avail.set(r.id, systemHas(r.probe));
    else avail.set(r.id, await faceLoaded(r.name));
  }
}

export function importedFaces(familyName) { return imported.filter(f => f.family.toLowerCase() === familyName.toLowerCase()); }

/* Guess family/style/weight from a filename such as "EBGaramond-Italic-VariableFont_wght.ttf". */
export function guessFromFilename(name) {
  const base = name.replace(/\.(ttf|otf|woff2?|)$/i, '');
  const italic = /italic|oblique/i.test(base);
  const variable = /variable|\[wght|_wght|vf\b/i.test(base);
  let weight = '400';
  if (variable) weight = '100 900';
  else if (/black|heavy/i.test(base)) weight = '900';
  else if (/extrabold|extra-bold/i.test(base)) weight = '800';
  else if (/semibold|semi-bold|demi/i.test(base)) weight = '600';
  else if (/bold/i.test(base)) weight = '700';
  else if (/medium/i.test(base)) weight = '500';
  let fam = base.split(/[-_ ]/)[0].replace(/\[.*\]/, '');
  fam = fam.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/^E B /, 'EB ').replace(/^EBGaramond$/i, 'EB Garamond');
  if (/^eb ?garamond/i.test(base)) fam = 'EB Garamond';
  return { family: fam.trim() || 'My Font', style: italic ? 'italic' : 'normal', weight };
}

/* Validate, register and persist an imported font file. */
export async function importFile(file, family) {
  const data = await file.arrayBuffer();
  const g = guessFromFilename(file.name);
  family = (family || g.family).trim();
  const face = new FontFace(family, data, { style: g.style, weight: g.weight });
  await face.load();                       // throws if the file is not a usable font
  document.fonts.add(face);
  const rec = { id: store.uid(), family, style: g.style, weight: g.weight, file: file.name, data, added: Date.now() };
  await store.put('fonts', rec);
  imported.push(rec);
  let entry = REGISTRY.find(r => r.name.toLowerCase() === family.toLowerCase());
  if (!entry) {
    entry = { id: 'u-' + slug(family), name: family, kind: 'imported', cat: 'serif', stack: `"${family}", ${FALL_SERIF}`, note: 'Added from your files.' };
    REGISTRY.push(entry);
  }
  avail.set(entry.id, true);
  return { entry, style: g.style, weight: g.weight };
}

const slug = s => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
