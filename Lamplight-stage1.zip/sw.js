/* Lamplight service worker: caches the app itself so it opens offline.
   It never sees your documents (they live in IndexedDB) and makes no other requests. */
const CACHE = 'lamplight-v0.1.0';
const SHELL = [
  './', './index.html', './manifest.webmanifest',
  './css/fonts.css', './css/lamplight.css',
  './js/app.js', './js/store.js', './js/fonts.js', './js/text.js', './js/ui.js',
  './icons/icon-180.png', './icons/icon-192.png', './icons/icon-512.png',
  "./fonts/CrimsonPro-Bold.woff",
  "./fonts/CrimsonPro-Italic.woff",
  "./fonts/CrimsonPro-Regular.woff",
  "./fonts/IBMPlexSerif-Bold.woff",
  "./fonts/IBMPlexSerif-BoldItalic.woff",
  "./fonts/IBMPlexSerif-Italic.woff",
  "./fonts/IBMPlexSerif-Regular.woff",
  "./fonts/InstrumentSerif-Italic.woff",
  "./fonts/InstrumentSerif-Regular.woff",
  "./fonts/Inter-Italic.woff",
  "./fonts/Inter-Medium.woff",
  "./fonts/Inter-Regular.woff",
  "./fonts/Inter-SemiBold.woff",
  "./fonts/LibreBaskerville-Regular.woff",
  "./fonts/Lora-Italic-Variable.woff",
  "./fonts/Lora-Variable.woff",
  "./fonts/Pagella-Bold.woff",
  "./fonts/Pagella-BoldItalic.woff",
  "./fonts/Pagella-Italic.woff",
  "./fonts/Pagella-Regular.woff",
];
const OPTIONAL = ['./fonts/EBGaramond-VariableFont_wght.ttf', './fonts/EBGaramond-Italic-VariableFont_wght.ttf'];
self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const c = await caches.open(CACHE);
    await c.addAll(SHELL);
    for (const u of OPTIONAL) { try { const r = await fetch(u); if (r.ok) await c.put(u, r); } catch (_) {} }
    self.skipWaiting();
  })());
});
self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k !== CACHE) await caches.delete(k);
    self.clients.claim();
  })());
});
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== location.origin) return;
  e.respondWith(caches.match(e.request, { ignoreSearch: true }).then(hit => hit || fetch(e.request).then(r => {
    if (r.ok) { const copy = r.clone(); caches.open(CACHE).then(c => c.put(e.request, copy)); }
    return r;
  }).catch(() => caches.match('./index.html'))));
});
